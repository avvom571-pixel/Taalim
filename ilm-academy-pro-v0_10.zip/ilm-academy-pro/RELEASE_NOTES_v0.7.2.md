# ILM ACADEMY PRO v0.7.2 — local startup fixes

- Vite now emits relative asset paths for local preview and Capacitor/static hosting.
- Manifest and embedded Mabdaul Qiroat HTML/PDF paths use relative URLs.
- The HTML root displays a loading fallback before React mounts.
- Global JavaScript errors and unhandled promise rejections now display a readable diagnostic instead of leaving a blank page.
- Supabase session initialization now times out with a visible message if the server does not respond.
- README clarifies that the app must be started with `npm run dev` and opened at the local Vite URL; opening `index.html` through `file://` is unsupported.

## Verification

The source and bundled PDFs are included. A clean dependency installation and production build could not be verified in this environment because `npm install --no-audit --no-fund` timed out. Run `npm install` and `npm run build` on the local machine before deployment.
