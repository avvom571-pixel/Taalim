import React, { Component, type ErrorInfo, type ReactNode } from "react";
type Props = { children: ReactNode };
type State = { error: Error | null };
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error("ILM ACADEMY runtime error", error, info); }
  render() {
    if (this.state.error) return <main style={{minHeight:"100vh",display:"grid",placeItems:"center",padding:24,background:"#f5f8f5",fontFamily:"sans-serif",color:"#20382b"}}><section style={{maxWidth:620,background:"white",padding:28,borderRadius:16,border:"1px solid #e3ebe4"}}><h1>Саҳифани очишда хатолик юз берди</h1><p>Сайт ишга тушди, лекин интерфейсда хатолик аниқланди. Қуйидаги маълумотни техник ёрдамга юборинг:</p><pre style={{whiteSpace:"pre-wrap",overflowWrap:"anywhere",background:"#f5f7f5",padding:14,borderRadius:8}}>{this.state.error.message}</pre><button onClick={()=>window.location.reload()} style={{padding:"11px 16px",border:0,borderRadius:8,background:"#123d32",color:"white"}}>Қайта юклаш</button></section></main>;
    return this.props.children;
  }
}
