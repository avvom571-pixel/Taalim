import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { createOrder, formatPrice, loadProducts, type Product } from "../lib/access";

const PAY_INSTRUCTIONS = (import.meta.env.VITE_PAY_INSTRUCTIONS as string | undefined) ?? "";
const CHECKOUT_ENABLED = import.meta.env.VITE_CHECKOUT_ENABLED === "true";
const PAY_CONTACT_URL = (import.meta.env.VITE_PAY_CONTACT_URL as string | undefined) ?? "";

export default function Paywall({ courseId, loggedIn, onClose }: { courseId?: string; loggedIn: boolean; onClose?: () => void }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [orderId, setOrderId] = useState<{ id: string; title: string } | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { loadProducts().then((all) => setProducts(courseId ? all.filter((p) => p.course_ids.includes(courseId)) : all)); }, [courseId]);

  async function buy(p: Product) {
    setBusy(true); setError("");
    try {
      const id = await createOrder(p.code, note);
      if (CHECKOUT_ENABLED && supabase) {
        // Card is entered on the payment provider's own page, never on this site.
        const { data, error: fnErr } = await supabase.functions.invoke("create-checkout", { body: { orderId: id } });
        if (!fnErr && data?.url) { window.location.href = data.url as string; return; }
      }
      setOrderId({ id, title: p.title });
    }
    catch (e) { setError(e instanceof Error ? e.message : "Буюртма яратилмади."); }
    finally { setBusy(false); }
  }

  if (orderId) return <div className="paywall">
    <h3>Буюртма қабул қилинди</h3>
    <p>Буюртма рақами: <b>{orderId.id.slice(0, 8).toUpperCase()}</b> · {orderId.title}</p>
    <p className="paywall-instr">{PAY_INSTRUCTIONS || "Тўлов йўриқномаси ҳали созланмаган: .env ичидаги VITE_PAY_INSTRUCTIONS ни тўлдиринг."}</p>
    <p>Тўловдан кейин буюртма рақамини ёзиб юборинг — администратор тасдиқлагач, дарслар автоматик очилади (саҳифани янгиланг).</p>
    {PAY_CONTACT_URL && <a className="primary-button" href={PAY_CONTACT_URL} target="_blank" rel="noreferrer">Тўловни тасдиқлаш учун ёзиш</a>}
  </div>;

  return <div className="paywall">
    <h3>Тўлиқ курсни очинг</h3>
    {!loggedIn && <p className="paywall-warn">Буюртма бериш учун аввал рўйхатдан ўтинг / киринг (Supabase уланган бўлиши керак).</p>}
    {products.length === 0 && <p className="paywall-warn">Бу материал ҳозирча сотувда эмас.</p>}
    <div className="plan-grid">{products.map((p) => <div className="plan-card" key={p.code}>
      <b>{p.title}</b><span className="plan-price">{formatPrice(p)}{p.duration_days ? <small> / {p.duration_days} кун</small> : <small> · бир марта</small>}</span>
      <button className="primary-button" disabled={busy || !loggedIn} onClick={() => buy(p)}>Буюртма бериш</button>
    </div>)}</div>
    <input className="paywall-note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Изоҳ (ихтиёрий): тўловчи исми ёки телефон охирги рақамлари" maxLength={300}/>
    {error && <p className="paywall-warn">{error}</p>}
    {onClose && <button className="text-button" onClick={onClose}>Ёпиш</button>}
  </div>;
}
