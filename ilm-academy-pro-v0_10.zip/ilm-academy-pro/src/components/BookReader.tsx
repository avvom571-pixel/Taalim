import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import Paywall from "./Paywall";

type Props = { courseId: "mabda-1" | "mabda-2"; title: string; entitled: boolean; loggedIn: boolean };

// Full book = private Supabase Storage object books/<course>/book.pdf served via a short-lived signed URL (entitled users / admins only).
// Without entitlement (or without a backend) only the small public preview is shown.
export default function BookReader({ courseId, title, entitled, loggedIn }: Props) {
  const [fullUrl, setFullUrl] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const preview = `./previews/${courseId}-preview.pdf`;
  useEffect(() => {
    let on = true;
    (async () => {
      if (!supabase || !loggedIn) return;
      const { data, error } = await supabase.storage.from("books").createSignedUrl(`${courseId}/book.pdf`, 3600);
      if (!on) return;
      if (error || !data) { setNote(entitled ? "Тўлиқ PDF ҳали юкланмаган ёки рухсат йўқ." : ""); return; }
      setFullUrl(data.signedUrl);
    })();
    return () => { on = false; };
  }, [courseId, loggedIn, entitled]);
  const src = fullUrl ?? preview;
  return <article className="lesson-viewer book-reader"><div className="lesson-viewer-head"><span className="eyebrow">{fullUrl ? "ТЎЛИҚ КИТОБ · PDF" : "ТАНИШУВ НУСХАСИ · 12 САҲИФА"}</span><h2>{title}</h2></div>
    <iframe className="book-pdf-frame" src={`${src}#view=FitH&toolbar=0`} title={title}/>
    {!fullUrl && <><p className="lesson-source-note">Бу фақат таништув қисми. {note}</p><Paywall courseId={courseId} loggedIn={loggedIn}/></>}
  </article>;
}
