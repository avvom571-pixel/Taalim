import { useEffect, useState } from "react";
import { Lock, CircleCheck } from "lucide-react";
import { courseLessonMeta, loadCourseLesson, type CourseLessonData, type CourseLessonMeta } from "../lib/content";
import Paywall from "./Paywall";

type Prog = Record<string, { courseId: string; done: boolean; score?: number }>;
type Props = { courseId: string; unlocked: boolean; loggedIn: boolean; progress: Prog; onSave: (key: string, done: boolean, score?: number) => void };

export default function DbCourse({ courseId, unlocked, loggedIn, progress, onSave }: Props) {
  const list = courseLessonMeta.filter((m) => m.courseId === courseId);
  const [open, setOpen] = useState<CourseLessonMeta | null>(null);
  const [showPay, setShowPay] = useState(false);
  const pk = (m: CourseLessonMeta) => `${m.courseId}/${m.key}`;
  const done = list.filter((m) => progress[pk(m)]?.done).length;
  return <div>
    <div className="section-heading"><div><span className="eyebrow">КУРС ДАСТУРИ</span><h2>Дарслар</h2></div><span className="pill">{done} / {list.length} тугалланган</span></div>
    {!unlocked && <div className="paywall-banner"><b>1-дарс бепул.</b> Қолган {list.filter((m) => !m.free).length} та дарс пуллик.<button className="primary-button" onClick={() => setShowPay(true)}>Тўлиқ очиш</button></div>}
    {showPay && !unlocked && <Paywall courseId={courseId} loggedIn={loggedIn} onClose={() => setShowPay(false)}/>}
    <div className="lesson-list">{list.map((m) => { const locked = !m.free && !unlocked; return <div key={m.key} className={`lesson-row ${open?.key === m.key ? "lesson-selected" : ""}`}>
      <div className="lesson-number">{String(m.n).padStart(2, "0")}</div>
      <div className="lesson-info"><b>{m.title}</b><small>{m.count} савол · {m.free ? "Бепул" : locked ? "Пуллик" : "Очиқ"}</small></div>
      {progress[pk(m)]?.done && <CircleCheck size={16} color="#3f7956"/>}
      <button className="icon-button" aria-label="Очиш" onClick={() => locked ? setShowPay(true) : setOpen(open?.key === m.key ? null : m)}>{locked ? <Lock size={15}/> : "›"}</button></div>; })}</div>
    {open && <Lesson key={open.key} meta={open} onSave={(score) => onSave(pk(open), score >= 60, score)}/>}
  </div>;
}

function Lesson({ meta, onSave }: { meta: CourseLessonMeta; onSave: (score: number) => void }) {
  const [state, setState] = useState<{ s: "load" } | { s: "ok"; d: CourseLessonData } | { s: "fail"; m: string }>({ s: "load" });
  const [picked, setPicked] = useState<Record<number, number>>({});
  const [saved, setSaved] = useState(false);
  useEffect(() => { let on = true; loadCourseLesson(meta.courseId, meta.key).then((r) => { if (on) setState(r.ok ? { s: "ok", d: r.data } : { s: "fail", m: r.message }); }); return () => { on = false; }; }, [meta.courseId, meta.key]);
  if (state.s === "load") return <p className="empty">Юкланмоқда…</p>;
  if (state.s === "fail") return <div className="source-warning">{state.m}</div>;
  const d = state.d; const answered = Object.keys(picked).length; const right = d.questions.filter((q, i) => picked[i] === q.answer).length;
  const score = Math.round((right / d.questions.length) * 100);
  return <article className="lesson-viewer"><div className="lesson-viewer-head"><span className="eyebrow">ДАРС</span><h2>{meta.title}</h2><p>{d.intro}</p></div>
    {d.sections.map((s, i) => <section className="lesson-content-section" key={i}><h3>{i + 1}. {s.heading}</h3><p>{s.body}</p>{s.arabic && <div className="arabic-example" dir="rtl" lang="ar">{s.arabic}</div>}{s.example && <p className="lesson-example">{s.example}</p>}</section>)}
    <div className="lesson-quiz"><h3>Ўзингизни текширинг</h3>{d.questions.map((q, qi) => <div key={qi}><p><b>{qi + 1}.</b> {q.prompt}</p>
      {q.options.map((o, oi) => <button key={oi} className={`quiz-option ${picked[qi] === oi ? "chosen" : ""}`} disabled={picked[qi] !== undefined} style={picked[qi] !== undefined && oi === q.answer ? { borderColor: "#3f7956" } : undefined} onClick={() => setPicked((p) => ({ ...p, [qi]: oi }))}>{String.fromCharCode(65 + oi)}. {o}</button>)}
      {picked[qi] !== undefined && <div className={picked[qi] === q.answer ? "quiz-feedback correct" : "quiz-feedback incorrect"}>{picked[qi] === q.answer ? "Тўғри! " : "Нотўғри. "}{q.explain}</div>}</div>)}
      {answered === d.questions.length && <><p><b>Натижа: {right} / {d.questions.length}</b> ({score}%)</p><button className="primary-button lesson-complete" disabled={saved} onClick={() => { onSave(score); setSaved(true); }}>{saved ? "Сақланди ✓" : "Натижани сақлаш"}</button></>}</div>
    <p className="lesson-source-note">{d.source}</p></article>;
}
