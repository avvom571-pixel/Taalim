import { useEffect, useMemo, useState } from "react";
import { Lock, CircleCheck, Volume2 } from "lucide-react";
import { loadMabda3Lesson, mabda3Meta, type LessonData, type LessonMeta, type TextData, type VocabData, type VocabItem } from "../lib/content";
import Paywall from "./Paywall";

type Prog = Record<string, { courseId: string; done: boolean; score?: number }>;
type Props = { unlocked: boolean; loggedIn: boolean; progress: Prog; onSave: (key: string, done: boolean, score?: number) => void };

const shuffle = <T,>(a: T[]) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };

export default function Mabda3Course({ unlocked, loggedIn, progress, onSave }: Props) {
  const [tab, setTab] = useState<"vocab" | "text">("vocab");
  const [open, setOpen] = useState<LessonMeta | null>(null);
  const [showPay, setShowPay] = useState(false);
  const list = useMemo(() => mabda3Meta.filter((m) => m.kind === tab), [tab]);
  const doneCount = mabda3Meta.filter((m) => progress[m.key]?.done).length;
  return <div className="m3">
    <div className="section-heading"><div><span className="eyebrow">МАБДАЪУЛ ҚИРОАТ 3</span><h2>Луғат ва ўқиш матнлари</h2></div><span className="pill">{doneCount} / {mabda3Meta.length} тугалланган</span></div>
    {!unlocked && <div className="paywall-banner"><b>Бепул: 5 та луғат дарси ва 3 та матн.</b> Қолган {mabda3Meta.filter((m) => !m.free).length} та дарс пуллик.<button className="primary-button" onClick={() => setShowPay(true)}>Тўлиқ очиш</button></div>}
    {showPay && !unlocked && <Paywall courseId="mabda-3" loggedIn={loggedIn} onClose={() => setShowPay(false)}/>}
    <div className="admin-tabs"><button className={tab === "vocab" ? "selected" : ""} onClick={() => { setTab("vocab"); setOpen(null); }}>Луғат (57)</button><button className={tab === "text" ? "selected" : ""} onClick={() => { setTab("text"); setOpen(null); }}>Матнлар (58)</button></div>
    <div className="lesson-list">{list.map((m) => { const locked = !m.free && !unlocked; return <div key={m.key} className={`lesson-row ${open?.key === m.key ? "lesson-selected" : ""}`}>
      <div className="lesson-number">{String(m.n).padStart(2, "0")}</div>
      <div className="lesson-info"><b>{m.title}</b><small>{m.count} {m.kind === "vocab" ? "сўз" : "жумла"} · {m.free ? "Бепул" : locked ? "Пуллик" : "Очиқ"}</small></div>
      {progress[m.key]?.done && <CircleCheck size={16} color="#3f7956"/>}
      <button className="icon-button" aria-label="Очиш" onClick={() => locked ? setShowPay(true) : setOpen(open?.key === m.key ? null : m)}>{locked ? <Lock size={15}/> : "›"}</button></div>; })}</div>
    {open && <Viewer key={open.key} meta={open} onSave={onSave}/>}
  </div>;
}

function Viewer({ meta, onSave }: { meta: LessonMeta; onSave: Props["onSave"] }) {
  const [state, setState] = useState<{ status: "loading" } | { status: "ready"; data: LessonData } | { status: "fail"; message: string }>({ status: "loading" });
  useEffect(() => { let on = true; loadMabda3Lesson(meta.key).then((r) => { if (on) setState(r.ok ? { status: "ready", data: r.data } : { status: "fail", message: r.message }); }); return () => { on = false; }; }, [meta.key]);
  if (state.status === "loading") return <p className="empty">Юкланмоқда…</p>;
  if (state.status === "fail") return <div className="source-warning">{state.message}</div>;
  return meta.kind === "vocab" ? <VocabViewer meta={meta} data={state.data as VocabData} onSave={onSave}/> : <TextViewer meta={meta} data={state.data as TextData} onSave={onSave}/>;
}

function speak(text: string) { try { const u = new SpeechSynthesisUtterance(text); u.lang = "ar-SA"; window.speechSynthesis.cancel(); window.speechSynthesis.speak(u); } catch { /* no TTS */ } }

function VocabViewer({ meta, data, onSave }: { meta: LessonMeta; data: VocabData; onSave: Props["onSave"] }) {
  const [mode, setMode] = useState<"learn" | "quiz">("learn");
  const [flipped, setFlipped] = useState<Record<number, boolean>>({});
  return <article className="lesson-viewer"><div className="lesson-viewer-head"><span className="eyebrow">ЛУҒАТ · {data.items.length} СЎЗ</span><h2>{meta.title}</h2></div>
    <div className="admin-tabs"><button className={mode === "learn" ? "selected" : ""} onClick={() => setMode("learn")}>Ўрганиш</button><button className={mode === "quiz" ? "selected" : ""} onClick={() => setMode("quiz")}>Тест</button></div>
    {mode === "learn" ? <>
      <div className="vocab-grid">{data.items.map((it, i) => <div key={i} className="vocab-card" onClick={() => setFlipped((f) => ({ ...f, [i]: !f[i] }))}>
        <div className="arabic-example" dir="rtl" lang="ar">{it.ar}</div>{flipped[i] ? <p className="lesson-example">{it.uz}</p> : <small>Таржимани кўриш учун босинг</small>}
        <button className="icon-button" aria-label="Талаффуз" onClick={(e) => { e.stopPropagation(); speak(it.ar); }}><Volume2 size={15}/></button></div>)}</div>
      <button className="primary-button lesson-complete" onClick={() => onSave(meta.key, true)}>Дарсни тугалладим</button></>
      : <Quiz items={data.items} onFinish={(score) => onSave(meta.key, score >= 70, score)}/>}
  </article>;
}

function Quiz({ items, onFinish }: { items: VocabItem[]; onFinish: (score: number) => void }) {
  const [dir, setDir] = useState<"ar-uz" | "uz-ar">("ar-uz");
  const [round, setRound] = useState(0);
  const questions = useMemo(() => shuffle(items).slice(0, 10).map((q) => ({ q, opts: shuffle([q, ...shuffle(items.filter((x) => x !== q)).slice(0, 3)]) })), [items, round]);
  const [i, setI] = useState(0); const [picked, setPicked] = useState<number | null>(null); const [right, setRight] = useState(0); const [done, setDone] = useState(false);
  const restart = () => { setRound((r) => r + 1); setI(0); setPicked(null); setRight(0); setDone(false); };
  if (done) { const score = Math.round((right / questions.length) * 100); return <div className="lesson-quiz"><h3>Натижа: {right} / {questions.length} ({score}%)</h3><p>{score >= 70 ? "Дарс тугалланди!" : "Қайта уриниб кўринг (70% керак)."}</p><button className="primary-button" onClick={restart}>Қайта бошлаш</button></div>; }
  const cur = questions[i]; const ans = cur.opts.indexOf(cur.q);
  const show = (x: VocabItem) => dir === "ar-uz" ? x.uz : x.ar;
  return <div className="lesson-quiz"><div className="admin-tabs"><button className={dir === "ar-uz" ? "selected" : ""} onClick={() => { setDir("ar-uz"); restart(); }}>Арабча → Ўзбекча</button><button className={dir === "uz-ar" ? "selected" : ""} onClick={() => { setDir("uz-ar"); restart(); }}>Ўзбекча → Арабча</button></div>
    <p><small>{i + 1} / {questions.length}</small></p>
    <div className={dir === "ar-uz" ? "arabic-example" : "lesson-example"} dir={dir === "ar-uz" ? "rtl" : "ltr"}>{dir === "ar-uz" ? cur.q.ar : cur.q.uz}</div>
    {cur.opts.map((o, k) => <button key={k} className={`quiz-option ${picked === k ? (k === ans ? "chosen" : "") : ""}`} disabled={picked !== null} style={picked !== null && k === ans ? { borderColor: "#3f7956" } : undefined} dir={dir === "ar-uz" ? "ltr" : "rtl"} onClick={() => { setPicked(k); if (k === ans) setRight((r) => r + 1); }}>{show(o)}</button>)}
    {picked !== null && <button className="primary-button" onClick={() => { if (i + 1 >= questions.length) { setDone(true); onFinish(Math.round(((right) / questions.length) * 100)); } else { setI(i + 1); setPicked(null); } }}>{i + 1 >= questions.length ? "Тугатиш" : "Кейингиси"}</button>}
  </div>;
}

function TextViewer({ meta, data, onSave }: { meta: LessonMeta; data: TextData; onSave: Props["onSave"] }) {
  const [shown, setShown] = useState<Record<number, boolean>>({});
  return <article className="lesson-viewer"><div className="lesson-viewer-head"><span className="eyebrow">ЎҚИШ МАТНИ</span><h2>{data.uzTitle}</h2><p dir="rtl" lang="ar" className="arabic-example">{data.arTitle}</p></div>
    {data.pairs.map((p, i) => <section className="lesson-content-section" key={i}><div className="arabic-example" dir="rtl" lang="ar">{p.ar}</div>
      <button className="secondary-button" onClick={() => setShown((s) => ({ ...s, [i]: !s[i] }))}>{shown[i] ? "Таржимани яшириш" : "Таржимани кўриш"}</button>{shown[i] && <p className="lesson-example">{p.uz}</p>}</section>)}
    <p className="lesson-source-note">Ўзбекча таржима сайт муаллифи томонидан қилинган, расмий таржима эмас; пуллик нашрдан олдин устоз текширувидан ўтказинг.</p>
    <button className="primary-button lesson-complete" onClick={() => onSave(meta.key, true)}>Матнни тугалладим</button></article>;
}
