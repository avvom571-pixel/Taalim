import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import AuthGate from "./AuthGate";
import ErrorBoundary from "./ErrorBoundary";
import "./styles.css";

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error('HTML ичида id="root" элементи топилмади. index.html файлини текширинг.');
}

function showStartupError(message: string) {
  rootElement!.innerHTML = "";
  const panel = document.createElement("main");
  panel.style.cssText = "min-height:100vh;display:grid;place-items:center;padding:24px;background:#f5f8f5;font-family:system-ui,sans-serif;color:#20382b";
  const card = document.createElement("section");
  card.style.cssText = "max-width:680px;width:100%;box-sizing:border-box;background:white;padding:24px;border:1px solid #e3ebe4;border-radius:16px";
  const title = document.createElement("h1");
  title.textContent = "ILM ACADEMY ишга тушмади";
  const detail = document.createElement("pre");
  detail.style.cssText = "white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f7f5;padding:14px;border-radius:8px";
  detail.textContent = message;
  const hint = document.createElement("p");
  hint.textContent = "Терминалда npm install ва npm run dev буйруқларини бажаринг. index.html файлини file:// орқали очманг.";
  card.append(title, detail, hint);
  panel.append(card);
  rootElement!.append(panel);
}

window.addEventListener("error", (event) => {
  if (event.error instanceof Error) showStartupError(event.error.message);
});
window.addEventListener("unhandledrejection", (event) => {
  const reason = event.reason;
  showStartupError(reason instanceof Error ? reason.message : String(reason ?? "Номаълум асинхрон хатолик"));
});

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <ErrorBoundary>
      <AuthGate>{(auth) => <App auth={auth} />}</AuthGate>
    </ErrorBoundary>
  </React.StrictMode>
);
