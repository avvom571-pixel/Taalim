import { useEffect, useMemo, useState } from "react";
import type { ComponentType, ReactNode } from "react";
import { BookOpen, GraduationCap, Home, Library, ChartNoAxesColumnIncreasing, UserRound, Search, Globe2, Play, Clock3, ArrowRight, Menu, X, Sparkles, ShieldCheck, LayoutDashboard, Users, Wallet, ClipboardList, Plus, Settings, Download, CircleCheck, TrendingUp, ExternalLink } from "lucide-react";
import { courses, type Course } from "./data/courses";
import { translations, type Language } from "./lib/i18n";
import { isBackendConfigured, supabase } from "./lib/supabase";
import type { AuthState, AcademyRole } from "./lib/auth";
import Mabda3Course from "./components/Mabda3Course";
import BookReader from "./components/BookReader";
import Paywall from "./components/Paywall";
import DbCourse from "./components/DbCourse";
import { loadUnlockedCourses, loadOrders, fulfilOrder, formatPrice, type OrderRow } from "./lib/access";
import { loadProgress, saveProgress } from "./lib/progress";
import { mabda3Meta } from "./lib/content";

type Page = "home" | "courses" | "pricing" | "library" | "progress" | "profile" | "admin";
const canAdminEarly = (r: AcademyRole) => r === "admin" || r === "super_admin";
type AdminTab = "overview" | "courses" | "students" | "teachers" | "payments" | "content";
export default function App({ auth }: { auth: AuthState & { role: AcademyRole } }) {
  const [lang, setLang] = useState<Language>("uz");
  const [page, setPage] = useState<Page>("home");
  const [query, setQuery] = useState("");
  const [activeCourse, setActiveCourse] = useState<string | null>(null);
  const [activeLesson, setActiveLesson] = useState<string | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [adminTab, setAdminTab] = useState<AdminTab>("overview");
  const [showAddCourse, setShowAddCourse] = useState(false);
  const [adminCourseName, setAdminCourseName] = useState("");
  const [adminCourses, setAdminCourses] = useState(courses);
  const [adminNotice, setAdminNotice] = useState("");
  const [savingCourse, setSavingCourse] = useState(false);
  const [unlocked, setUnlocked] = useState<string[]>([]);
  const [progressStore, setProgressStore] = useState<Record<string, { courseId: string; done: boolean; score?: number }>>({});
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const t = translations[lang];
  const userId = auth.user?.id;
  useEffect(() => { loadUnlockedCourses().then(setUnlocked); loadProgress(userId).then(setProgressStore); }, [userId]);
  useEffect(() => { if (page === "admin" && canAdminEarly(auth.role)) loadOrders().then(setOrders); }, [page, auth.role]);
  const isUnlocked = (courseId: string) => auth.role === "admin" || auth.role === "super_admin" || unlocked.includes(courseId);
  async function markProgress(courseId: string, key: string, done: boolean, score?: number) { setProgressStore(await saveProgress(userId, key, courseId, done, score)); }
  async function confirmOrder(id: string) { try { await fulfilOrder(id); setOrders(await loadOrders()); setAdminNotice("Тўлов тасдиқланди, рухсат берилди."); } catch (e) { setAdminNotice(e instanceof Error ? e.message : "Тасдиқланмади."); } }
  const filtered = useMemo(() => adminCourses.filter(c => `${c.title} ${c.category}`.toLowerCase().includes(query.toLowerCase())), [adminCourses, query]);
  const canAdmin = auth.role === "admin" || auth.role === "super_admin";
  useEffect(() => {
    if (!supabase || !canAdmin) return;
    let active = true;
    (async () => {
      const { data, error } = await supabase.from("courses").select("id, slug, level, status, course_translations(language, title, description)").order("created_at", { ascending: false });
      if (!active) return;
      if (error) { setAdminNotice(`База маълумотларини юклашда хатолик: ${error.message}`); return; }
      const rows = (data ?? []) as Array<{id:string;slug:string;level:string;status:string;course_translations?:Array<{language:string;title:string;description:string}>}>;
      if (rows.length) {
        const fromDb: Course[] = rows.map((row) => {
          const tr = row.course_translations?.find((item) => item.language === lang) ?? row.course_translations?.[0];
          return { id: row.id, title: tr?.title ?? row.slug, category: "Академия курси", level: row.level ?? "Бошланғич", lessons: 0, duration: "Белгиланмаган", description: tr?.description ?? "", color: "mint", progress: 0, program: "ILM ACADEMY" };
        });
        setAdminCourses((current) => [...current.filter((item) => !fromDb.some((db) => db.id === item.id)), ...fromDb]);
        setAdminNotice(`Базадан ${rows.length} та курс юкланди.`);
      }
    })();
    return () => { active = false; };
  }, [canAdmin, lang]);
  async function addCourse() {
    const title = adminCourseName.trim();
    if (!title || savingCourse) return;
    setSavingCourse(true); setAdminNotice("");
    try {
      if (supabase && auth.user && canAdmin) {
        const slug = `${title.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 42) || "academy-course"}-${Date.now().toString().slice(-6)}`;
        const { data, error } = await supabase.from("courses").insert({ slug, status: "draft", level: "beginner" }).select("id").single();
        if (error) throw error;
        const { error: translationError } = await supabase.from("course_translations").insert({ course_id: data.id, language: "uz", title, description: "Администратор томонидан қўшилган курс." });
        if (translationError) {
          await supabase.from("courses").delete().eq("id", data.id);
          throw translationError;
        }
        setAdminCourses((prev) => [...prev, { id: data.id, title, category: "Янги курс", level: "Бошланғич", lessons: 0, duration: "Белгиланмаган", description: "Администратор томонидан қўшилган курс.", color: "mint", progress: 0, program: "ILM ACADEMY" }]);
        setAdminNotice("Курс Supabase базасига сақланди.");
      } else {
        setAdminCourses((prev) => [...prev, { id: `custom-${Date.now()}`, title, category: "Янги курс", level: "Бошланғич", lessons: 0, duration: "Белгиланмаган", description: "Демо курс.", color: "mint", progress: 0, program: "Янги дастур" }]);
        setAdminNotice("Демо режим: курс фақат шу браузер сессиясида сақланади. Supabase уланмаган.");
      }
      setAdminCourseName(""); setShowAddCourse(false);
    } catch (err) {
      setAdminNotice(err instanceof Error ? `Курс сақланмади: ${err.message}` : "Курс сақланмади.");
    } finally { setSavingCourse(false); }
  }
  const nav = [
    { id: "home" as Page, label: t.home, icon: Home },
    { id: "courses" as Page, label: t.courses, icon: BookOpen },
    { id: "pricing" as Page, label: "Тарифлар", icon: Wallet },
    { id: "library" as Page, label: t.library, icon: Library },
    { id: "progress" as Page, label: t.progress, icon: ChartNoAxesColumnIncreasing },
    { id: "profile" as Page, label: t.profile, icon: UserRound }
  ];
  const selected = adminCourses.find(c => c.id === activeCourse);
  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><GraduationCap size={23}/></div><div><b>ILM ACADEMY</b><small>PRO LEARNING</small></div><button className="close-menu" onClick={() => setMobileMenu(false)}><X/></button></div>
      <div className="workspace-label">LEARNING SPACE</div>
      <nav>{nav.map(item => <button key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} onClick={() => {setPage(item.id);setActiveCourse(null);setActiveLesson(null);setMobileMenu(false);}}><item.icon size={18}/><span>{item.label}</span></button>)}</nav>
      <div className="sidebar-bottom">{canAdmin && <button className={`nav-item admin-nav ${page === "admin" ? "active" : ""}`} onClick={() => {setPage("admin");setActiveCourse(null);setActiveLesson(null);setMobileMenu(false);}}><LayoutDashboard size={18}/><span>Админ-панель</span></button>}<button className="upgrade-card" style={{border:0,textAlign:"left",width:"100%"}} onClick={() => {setPage("pricing");setActiveCourse(null);setMobileMenu(false);}}><Sparkles size={19}/><b>Тўлиқ дарсларни очинг</b><p>Тарифлар ва курс нархлари.</p><span>PREMIUM</span></button><div className="profile-mini"><div className="avatar">IA</div><div><b>{auth.user?.user_metadata?.display_name || auth.user?.email || "Demo Student"}</b><small>{auth.user ? auth.role : t.demo}</small></div>{auth.user && <button className="signout" onClick={() => supabase?.auth.signOut()} title="Чиқиш">↗</button>}</div></div>
    </aside>
    {mobileMenu && <button className="scrim" onClick={() => setMobileMenu(false)} aria-label="Close menu"/>}
    <main className="main-area">
      <header className="topbar"><button className="menu-toggle" onClick={() => setMobileMenu(true)}><Menu/></button><div className="breadcrumb">ILM ACADEMY <span>/</span> {selected ? selected.title : nav.find(n => n.id === page)?.label}</div><div className="top-actions"><div className="language-select"><Globe2 size={16}/><select value={lang} onChange={e => setLang(e.target.value as Language)} aria-label="Language"><option value="uz">O‘zbekcha</option><option value="ky">Кыргызча</option><option value="ru">Русский</option></select></div><div className="avatar top-avatar">IA</div></div></header>
      <div className="content">
        {page === "admin" && canAdmin ? <AdminPanel tab={adminTab} setTab={setAdminTab} showAdd={showAddCourse} setShowAdd={setShowAddCourse} courseName={adminCourseName} setCourseName={setAdminCourseName} addCourse={addCourse} savingCourse={savingCourse} notice={adminNotice} courses={adminCourses} orders={orders} onConfirm={confirmOrder} /> : page === "admin" ? <EmptyPage icon={<ShieldCheck/>} title="Админ рухсати йўқ" desc="Админ-панелга кириш учун администратор ҳуқуқи керак."/> : selected ? <section className="course-detail"><button className="back-link" onClick={() => {setActiveCourse(null);setActiveLesson(null)}}>← {t.all}</button><div className={`detail-banner ${selected.color}`}><span className="eyebrow">ILM ACADEMY · COURSE</span><h1>{selected.title}</h1><p>{selected.description}</p><div className="detail-meta"><span><BookOpen size={15}/>{selected.lessons} {t.lessons}</span><span><Clock3 size={15}/>{selected.duration}</span><span>{selected.level}</span></div></div>{selected.id === "nahw-advanced" || selected.id === "sarf-advanced" ? <DbCourse courseId={selected.id} unlocked={isUnlocked(selected.id)} loggedIn={Boolean(auth.user)} progress={progressStore} onSave={(key, done, score) => markProgress(selected.id, `${selected.id}/${key.split("/")[1]}`, done, score)}/> : selected.id === "mabda-3" ? <Mabda3Course unlocked={isUnlocked("mabda-3")} loggedIn={Boolean(auth.user)} progress={progressStore} onSave={(key, done, score) => markProgress("mabda-3", key, done, score)}/> : selected.id === "mabda-1" || selected.id === "mabda-2" ? <BookReader courseId={selected.id} title={selected.title} entitled={isUnlocked(selected.id)} loggedIn={Boolean(auth.user)}/> : <><div className="section-heading"><div><span className="eyebrow">YOUR LEARNING PATH</span><h2>Курс дастури</h2></div><span className="pill">{courseLessons(selected.id).filter(item=>progressStore[item.id]?.done).length} / {courseLessons(selected.id).length} тугалланган</span></div><div className="lesson-list">{courseLessons(selected.id).map((lesson,i)=><div className={`lesson-row ${activeLesson===lesson.id?"lesson-selected":""}`} key={lesson.id}><div className="lesson-number">{String(i+1).padStart(2,"0")}</div><div className="lesson-info"><b>{lesson.title}</b><small>{lesson.duration} · {lesson.kind === "source-needed" ? "Манба тайёрланмоқда" : lesson.kind === "source-book" ? "Асл PDF китоб" : "Матнли дарс ва машқ"}</small></div><button className="icon-button" onClick={() => setActiveLesson(activeLesson===lesson.id?null:lesson.id)} aria-label="Дарсни очиш"><Play size={16}/></button></div>)}</div>{activeLesson && <LessonViewer key={activeLesson} courseId={selected.id} lessonId={activeLesson} completed={Boolean(progressStore[activeLesson]?.done)} onComplete={()=>markProgress(selected.id, activeLesson, true)}/> }</>}</section> :
        page === "home" ? <>
          <section className="hero"><div className="hero-copy"><span className="eyebrow light">YOUR JOURNEY TO KNOWLEDGE</span><h1>{t.welcome}</h1><p>{t.subtitle}</p><button className="primary-button" onClick={() => setPage("courses")}>{t.explore}<ArrowRight size={17}/></button><div className="hero-foot"><span><ShieldCheck size={15}/> Босқичли таълим</span><span><Globe2 size={15}/> 3 тилда</span></div></div><div className="hero-art"><div className="orb orb-one"/><div className="orb orb-two"/><div className="book-illustration"><BookOpen size={86} strokeWidth={1.1}/><span>اِقْرَأْ</span></div><div className="floating-note">علمٌ نافعٌ</div></div></section>
          <div className="stats-grid"><div className="stat-card"><div className="stat-icon green"><BookOpen/></div><div><b>7</b><small>Курс режалари</small></div></div><div className="stat-card"><div className="stat-icon gold"><GraduationCap/></div><div><b>{academyLessons.filter(item=>item.kind === "content").length}</b><small>Тайёр намунавий дарс</small></div></div><div className="stat-card"><div className="stat-icon violet"><ChartNoAxesColumnIncreasing/></div><div><b>—</b><small>Ўқиш натижаси ҳали синхронланмаган</small></div></div></div>
          <div className="section-heading"><div><span className="eyebrow">CURATED FOR YOU</span><h2>{t.featured}</h2></div><button className="text-button" onClick={() => setPage("courses")}>{t.all}<ArrowRight size={15}/></button></div>
          <div className="course-grid">{adminCourses.slice(0,3).map(c => <CourseCard key={c.id} course={c} onClick={() => {setActiveCourse(c.id);setActiveLesson(null)}} t={t}/>)}</div>
        </> :
        page === "courses" ? <><div className="page-intro"><span className="eyebrow">EXPLORE & LEARN</span><h1>{t.all}</h1><p>Ўз даражангизга мос курсни танланг ва ўқишни бошланг.</p></div><div className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder={t.search}/></div><div className="course-grid">{filtered.map(c => <CourseCard key={c.id} course={c} onClick={() => {setActiveCourse(c.id);setActiveLesson(null)}} t={t}/>)}</div>{filtered.length===0 && <p className="empty">Курс топилмади.</p>}</> :
        page === "pricing" ? <section className="pricing-page"><div className="page-intro"><span className="eyebrow">ТАРИФЛАР</span><h1>Тўлиқ дарсларни очинг</h1><p>Бепул дарслар ҳар доим очиқ. Тўлов тасдиқлангач, рухсат аккаунтингизга автоматик берилади.</p></div><Paywall loggedIn={Boolean(auth.user)}/></section> :
        page === "library" ? <section><div className="page-intro"><span className="eyebrow">КУТУБХОНА</span><h1>{t.library}</h1><p>Китоблар ва интерактив материаллар.</p></div><div className="course-grid">{adminCourses.filter(c=>c.program==="Мабдаъул Қироат").map(c=><CourseCard key={c.id} course={c} onClick={() => {setPage("courses");setActiveCourse(c.id);setActiveLesson(null)}} t={t}/>)}</div></section> :
        page === "progress" ? <section><div className="page-intro"><span className="eyebrow">НАТИЖАЛАР</span><h1>{t.progress}</h1><p>{auth.user ? "Натижалар аккаунтингизга сақланади." : "Киришсиз натижалар фақат шу браузерда сақланади."}</p></div>{(() => { const done = Object.entries(progressStore).filter(([,v]) => v.done); const scores = Object.values(progressStore).map(v => v.score).filter((x): x is number => typeof x === "number"); const avg = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : null; return <><div className="stats-grid"><div className="stat-card"><div><b>{done.length}</b><small>Тугаллаган дарс</small></div></div><div className="stat-card"><div><b>{mabda3Meta.length}</b><small>Мабдаъ 3 жами дарс</small></div></div><div className="stat-card"><div><b>{avg === null ? "—" : avg + "%"}</b><small>Ўртача тест натижаси</small></div></div></div>{done.length === 0 && <p className="empty">Ҳали тугалланган дарс йўқ.</p>}</>; })()}</section> :
        <section><div className="page-intro"><span className="eyebrow">ПРОФИЛЬ</span><h1>{t.profile}</h1></div><div className="admin-panel-card"><p><b>{auth.user?.user_metadata?.display_name || auth.user?.email || "Меҳмон (демо)"}</b></p><p>Рол: {auth.user ? auth.role : "—"}</p><p>Очиқ курслар: {unlocked.length ? unlocked.join(", ") : "фақат бепул дарслар"}</p>{auth.user && <button className="secondary-button" onClick={() => supabase?.auth.signOut()}>Чиқиш</button>}</div></section>}
        <footer className="footer"><span>© 2026 ILM ACADEMY PRO</span><span>{isBackendConfigured ? "Backend configured" : t.backend}</span></footer>
      </div>
    </main>
  </div>;
}

type AcademyLesson = { id: string; courseId: string; title: string; duration: string; kind: "content" | "source-needed" | "source-book"; intro: string; sourceNote?: string; sourcePdf?: string; sections: { heading: string; body: string; arabic?: string; example?: string }[]; question?: { prompt: string; options: string[]; answer: number; explain: string } };
const academyLessons: AcademyLesson[] = [
  { id:"nahw-1-1", courseId:"nahw-intro", title:"1-дарс. Наҳв илми ва калом", duration:"12 дақиқа", kind:"content", intro:"Наҳв араб тилида сўзларнинг жумладаги вазифаси ва охирги ҳаракатларини ўрганишга ёрдам беради.", sourceNote:"Қоида асоси: Матн ал-Ожуррумия, муқаддима. Ўзбекча тушунтириш ўқув мақсадида қайта баён қилинган; нашрдан олдин устоз текширувидан ўтказилади.", sections:[
    {heading:"Калом таърифи",body:"«Ал-Ожуррумия» муқаддимасида калом қуйидагича таърифланади: талаффуз қилинган, таркибли, маънони тўлиқ ифодаловчи ва араб тилида қўлланадиган ифода. Бу таърифда тўрт жиҳат бор: лафз, таркиб, фойда ва вазъ.",arabic:"الكَلَامُ هُوَ اللَّفْظُ المُرَكَّبُ المُفِيدُ بِالوَضْعِ"},
    {heading:"Мисолни таҳлил қиламиз",body:"جَاءَ زَيْدٌ — «Зайд келди». Бу ерда جَاءَ феъл, زَيْدٌ эса фоил бўлиб, гап тўлиқ маъно беради. Аммо زَيْدٌ وحده (ёлғиз «Зайд») тўлиқ хабар бермайди.",arabic:"جَاءَ زَيْدٌ",example:"جَاءَ — келди (феъл); زَيْدٌ — Зайд (фоил, марфуъ)."},
    {heading:"Наҳв нима учун керак?",body:"Наҳв сўзнинг гапдаги ўрнини англаш, иъробни тўғри ўқиш ва арабча матнни маъноси билан тушунишга хизмат қилади. Иъробни фақат охирги ҳаракатни ёдлаш деб эмас, балки сўзнинг гапдаги вазифаси билан боғлаб ўрганинг."}
  ],question:{prompt:"«جَاءَ زَيْدٌ» ибораси нима учун калом ҳисобланади?",options:["Чунки битта сўздан иборат","Чунки таркибли ва тўлиқ маъно беради","Чунки унда фақат исм бор"],answer:1,explain:"Ифода феъл ва фоилдан таркиб топган ҳамда тўлиқ хабарни англатади."}},
  { id:"nahw-1-2", courseId:"nahw-intro", title:"2-дарс. Калима турлари: исм, феъл, ҳарф", duration:"15 дақиқа", kind:"content", intro:"Араб тилида калима уч асосий турга бўлинади: исм, феъл ва ҳарф.", sourceNote:"Қоида асоси: Матн ал-Ожуррумия, «Боб ал-калом». Мисоллар ўқув учун танланган.", sections:[
    {heading:"Исм (الاِسْمُ)",body:"Исм маънони ўзи англатади, лекин ўз-ўзидан замонни билдирмайди. Одам, жой, нарса ва маъно номлари исм бўлиши мумкин.",arabic:"زَيْدٌ، كِتَابٌ، مَسْجِدٌ",example:"زَيْدٌ — Зайд; كِتَابٌ — китоб; مَسْجِدٌ — масжид."},
    {heading:"Феъл (الفِعْلُ)",body:"Феъл маъно билан бирга замонни ҳам билдиради. Асосий турлари: мозий (ўтган замон), музореъ (ҳозирги/келаси замон маъноси), амр (буйруқ).",arabic:"كَتَبَ — يَكْتُبُ — اُكْتُبْ",example:"كَتَبَ — ёзди; يَكْتُبُ — ёзяпти/ёзади; اُكْتُبْ — ёз!"},
    {heading:"Ҳарф (الحَرْفُ)",body:"Ҳарфнинг маъноси бошқа сўз билан бирикканда тўлиқроқ англашилади. Масалан, مِنْ — «дан», إِلَى — «гача/томон», فِي — «ичида».",arabic:"مِنْ، إِلَى، فِي",example:"فِي البَيْتِ — уйда. فِي ҳарфи البَيْتِ исми билан бирикди."}
  ],question:{prompt:"يَكْتُبُ қайси калима турига киради?",options:["Исм","Феъл","Ҳарф"],answer:1,explain:"يَكْتُبُ феъл бўлиб, музореъ шаклида келган."}},
  { id:"nahw-1-3", courseId:"nahw-intro", title:"3-дарс. Исмнинг аломатлари", duration:"14 дақиқа", kind:"content", intro:"Исмни феъл ва ҳарфдан ажратиш учун унинг грамматик аломатларини ўрганамиз.", sourceNote:"Қоида асоси: Матн ал-Ожуррумия, «Боб ал-калом»да исмнинг аломатлари баёни.", sections:[
    {heading:"Жар (الجرّ)",body:"Исм жар ҳолатида келиши мумкин. Кўпинча مِنْ، إِلَى، عَنْ، عَلَى، فِي каби жар ҳарфларидан кейинги исм мажрур бўлади.",arabic:"فِي المَسْجِدِ",example:"المَسْجِدِ — «масжид»; فِي жар ҳарфидан кейин келгани учун касра билан мажрур."},
    {heading:"Танвин (التنوين)",body:"Танвин исмнинг охирида эшитиладиган нун товушига ўхшаш қўшимча белгидир: ـٌ، ـٍ، ـً. Танвин ҳар доим ҳам келавермайди; масалан, ال билан бошланган исм одатда танвин қабул қилмайди.",arabic:"كِتَابٌ، كِتَابًا، كِتَابٍ"},
    {heading:"ال алиф-лом",body:"Исм ال билан бошланиши мумкин: الكِتَابُ — китоб. Бу ҳам исмни таниш аломатларидан бири. Исмнинг бошқа аломатлари ҳам бор; бу дарсда энг кўп учрайдиганларини кўрдик.",arabic:"الكِتَابُ"}
  ],question:{prompt:"فِي المَسْجِدِ бирикмасида المَسْجِدِ нима учун касрали?",options:["Жар ҳарфидан кейин келгани учун","Феъл бўлгани учун","Амр шакли бўлгани учун"],answer:0,explain:"فِي жар ҳарфи бўлиб, ундан кейинги исмни мажрур қилади."}},
  { id:"sarf-1-1", courseId:"sarf-intro", title:"1-дарс. Сарф илмига кириш", duration:"13 дақиқа", kind:"content", intro:"Сарф калиманинг тузилиши ва шакл ўзгаришларини, айниқса феъл ва исмнинг турли вазнларини ўрганади.", sourceNote:"Сарфнинг бошланғич қоидалари бўйича муаллифлик тушунтириши. Мисоллар классик араб сарфи намунаси асосида; устоз таҳрири талаб қилинади.", sections:[
    {heading:"Сарфнинг вазифаси",body:"Сарф орқали бир илдиздан турли маънодаги шакллар қандай ясалишини кўрамиз. Наҳв сўзнинг жумладаги вазифасига эътибор берса, сарф сўзнинг ички тузилиши ва шаклига эътибор беради."},
    {heading:"Феълнинг уч асосий шакли",body:"Кўп учрайдиган уч шакл: мозий, музореъ ва амр. Уларнинг ҳар бири замон ёки буйруқ маъносини ифодалайди.",arabic:"نَصَرَ — يَنْصُرُ — اُنْصُرْ",example:"نَصَرَ — ёрдам берди; يَنْصُرُ — ёрдам беради; اُنْصُرْ — ёрдам бер!"},
    {heading:"Илдиз ва вазн",body:"ن ص ر ҳарфлари мисолимизда асосий илдиздир. فَعَلَ эса вазнни кўрсатувчи намуна. Илдиз ҳарфларини ف، ع، ل ўринларига қўйиб, сўз шаклини таҳлил қиламиз.",arabic:"فَعَلَ ← نَصَرَ",example:"ف = ن، ع = ص، ل = ر."}
  ],question:{prompt:"نَصَرَ қайси шакл?",options:["Мозий","Музореъ","Амр"],answer:0,explain:"نَصَرَ ўтган замон феъли — мозий."}},
  { id:"sarf-1-2", courseId:"sarf-intro", title:"2-дарс. Феъл мозий ва музореъ", duration:"16 дақиқа", kind:"content", intro:"Мозий ўтган иш-ҳаракатни, музореъ эса контекстга қараб ҳозирги ёки келаси иш-ҳаракатни билдиради.", sourceNote:"Сарфнинг бошланғич қоидалари бўйича муаллифлик тушунтириши; мисоллар устоз томонидан текширилиши керак.", sections:[
    {heading:"Мозий",body:"Мозий феъли ўтган замонда содир бўлган ишни билдиради. Мисол: فَتَحَ — очди.",arabic:"فَتَحَ"},
    {heading:"Музореъ",body:"Музореъ феъли одатда أ، ن، ي، ت ҳарфларидан бири билан бошланади. Мисол: يَفْتَحُ — у очади/очяпти.",arabic:"يَفْتَحُ"},
    {heading:"Жуфтлаб ёдлаш",body:"Феълни алоҳида эмас, мозий ва музореъ жуфти билан ёдланг. Бу вазнни сезиш ва луғатни мустаҳкамлашга ёрдам беради.",arabic:"فَتَحَ — يَفْتَحُ",example:"Ҳар бир феълни луғатдан унинг боб ва масдари билан текшириш одатини шакллантиринг."}
  ],question:{prompt:"يَفْتَحُ қайси шакл?",options:["Мозий","Музореъ","Амр"],answer:1,explain:"يَفْتَحُ музореъ феълидир; يـ бошланғич ҳарфи уни танишга ёрдам беради."}},
  { id:"mabda-1-pdf", courseId:"mabda-1", title:"Мабдаъ ул-қироат — 1-китоб (тўлиқ PDF)", duration:"143 саҳифа", kind:"source-book", intro:"Фойдаланувчи тақдим этган асл китоб. PDF тўлиқ китоб сифатида ўқилади; алоҳида интерактив дарсларга ажратиш кейинги иш босқичидир.", sourcePdf:"./mabdaul-qiroat/mabdaul-qiroat-1.pdf", sourceNote:"Arabic.uz, Тошкент, 2014.", sections:[]},
  { id:"mabda-2-pdf", courseId:"mabda-2", title:"Мабдаъ ул-қироат — 2-китоб (тўлиқ PDF)", duration:"158 саҳифа", kind:"source-book", intro:"Фойдаланувчи тақдим этган асл китоб. PDF тўлиқ китоб сифатида ўқилади; алоҳида интерактив дарсларга ажратиш кейинги иш босқичидир.", sourcePdf:"./mabdaul-qiroat/mabdaul-qiroat-2.pdf", sourceNote:"Arabic.uz, Тошкент, 2015.", sections:[]},
  { id:"mabda-3-1", courseId:"mabda-3", title:"Мабдаъул Қироат 3 — манба дарси", duration:"Манба керак", kind:"source-needed", intro:"Учинчи китобнинг аниқ дарсларини манбага мос равишда тайёрлаймиз. Сиз юборган APK веб-сайтга йўналтирувчи илова экан; унинг саҳифалари мустақил манба файллари сифатида APK ичида сақланмаган.", sections:[{heading:"Дарс таркиби",body:"Ҳар бир дарсда китобдаги арабча матн, луғат, сарф-наҳв таҳлили, ўзбекча таржима, аудио ва текширув тестлари бўлади."}]}
];
function courseLessons(courseId:string): AcademyLesson[] {
  const found=academyLessons.filter(item=>item.courseId===courseId);
  if(found.length) return found;
  const book=courseId==="mabda-2"?"Мабдаъул Қироат 2":courseId==="mabda-3"?"Мабдаъул Қироат 3":courseId==="nahw-advanced"?"Наҳв: иъроб ва жумлалар":"Сарф: феъллар таҳлили";
  return [{id:`${courseId}-source`,courseId,title:`${book} — китоб асосидаги дарслар`,duration:"Манба керак",kind:"source-needed" as const,intro:"Бу китобнинг ҳақиқий дарсларини киритиш учун PDF ёки саҳифа расмлари керак. Манбасиз мазмунни китобдан олинган деб кўрсатмаймиз.",sections:[{heading:"Кейинги тайёрлаш тартиби",body:"Китоб саҳифаларини юборинг. Ҳар бир мавзу арабча асл матн, ўзбекча тушунтириш, сўзлар луғати, талаффуз аудиоси, машқ ва тест билан тайёрланади."}]}];
}
function LessonViewer({courseId,lessonId,completed,onComplete}:{courseId:string;lessonId:string;completed:boolean;onComplete:()=>void}) {
  const lesson=academyLessons.find(item=>item.id===lessonId) ?? courseLessons(courseId).find(item=>item.id===lessonId);
  const [answer,setAnswer]=useState<number|null>(null);
  if(!lesson) return null;
  if(lesson.sourcePdf) return <article className="lesson-viewer book-reader"><div className="lesson-viewer-head"><span className="eyebrow">АСЛ КИТОБ · PDF</span><h2>{lesson.title}</h2><p>{lesson.intro}</p><div className="book-reader-actions"><a className="primary-button" href={lesson.sourcePdf} target="_blank" rel="noreferrer">Китобни очиш <ExternalLink size={16}/></a><a className="secondary-button" href={lesson.sourcePdf} download>PDF ни юклаб олиш <Download size={16}/></a></div></div><iframe className="book-pdf-frame" src={`${lesson.sourcePdf}#view=FitH`} title={lesson.title} loading="lazy"/><p className="lesson-source-note">Манба: {lesson.sourceNote} Оммавий тарқатиш ҳуқуқини алоҳида текшириш зарур.</p></article>;
  return <article className="lesson-viewer"><div className="lesson-viewer-head"><span className="eyebrow">ДАРС МАТЕРИАЛИ · {lesson.duration}</span><h2>{lesson.title}</h2><p>{lesson.intro}</p></div>{lesson.sections.map((section,index)=><section className="lesson-content-section" key={section.heading}><h3>{index+1}. {section.heading}</h3><p>{section.body}</p>{section.arabic&&<div className="arabic-example" dir="rtl" lang="ar">{section.arabic}</div>}{section.example&&<p className="lesson-example">{section.example}</p>}</section>)}{lesson.sourceNote&&<p className="lesson-source-note">Манба ва таҳрир: {lesson.sourceNote}</p>}{lesson.question&&<div className="lesson-quiz"><h3>Ўзингизни текширинг</h3><p>{lesson.question.prompt}</p>{lesson.question.options.map((option,index)=><button key={option} className={`quiz-option ${answer===index?"chosen":""}`} onClick={()=>setAnswer(index)}>{String.fromCharCode(65+index)}. {option}</button>)}{answer!==null&&<div className={answer===lesson.question!.answer?"quiz-feedback correct":"quiz-feedback incorrect"}>{answer===lesson.question!.answer?"Тўғри жавоб!":"Жавоб нотўғри. Қайта кўриб чиқинг."} {lesson.question.explain}</div>}</div>}{lesson.kind==="source-needed"&&<div className="source-warning">Китобнинг PDF нусхаси ёки саҳифа расмларини юборинг — аниқ матнни шу манба асосида киритамиз.</div>}{lesson.kind === "content" && <button className="primary-button lesson-complete" onClick={onComplete} disabled={completed}>{completed?"Дарс тугалланган ✓":"Дарсни тугалладим"}</button>}</article>;
}

function AdminPanel({tab,setTab,showAdd,setShowAdd,courseName,setCourseName,addCourse,savingCourse,notice,courses,orders,onConfirm}:{orders:OrderRow[],onConfirm:(id:string)=>void,tab:AdminTab,setTab:(v:AdminTab)=>void,showAdd:boolean,setShowAdd:(v:boolean)=>void,courseName:string,setCourseName:(v:string)=>void,addCourse:()=>void,savingCourse:boolean,notice:string,courses:Course[]}) {
  const tabs:[AdminTab,string,ComponentType<any>][] = [["overview","Обзор",LayoutDashboard],["courses","Курсы",BookOpen],["students","Ученики",Users],["teachers","Преподаватели",GraduationCap],["payments","Платежи",Wallet],["content","Материалы",ClipboardList]];
  return <section className="admin-page">
    <div className="admin-heading"><div><span className="eyebrow">ACADEMY MANAGEMENT</span><h1>Панель управления</h1><p>Управляйте учебным процессом, контентом и работой академии.</p></div><span className="admin-demo"><ShieldCheck size={14}/> ҲАҚИҚИЙ СТАТИСТИКА ФАҚАТ БАЗАДАН ОЛИНАДИ</span></div>
    <div className="admin-tabs">{tabs.map(([id,label,Icon])=><button key={id} className={tab===id?"selected":""} onClick={()=>setTab(id)}><Icon size={16}/>{label}</button>)}</div>
    {tab === "overview" && <>
      <div className="admin-metrics"><Metric icon={<Users/>} label="Реал рўйхатдан ўтган ўқувчилар" value="—" delta="Профиллар базасига уланмаган"/><Metric icon={<BookOpen/>} label="Курс режалари" value={String(courses.length)} delta="Ҳали тўлиқ нашр қилинмаган"/><Metric icon={<TrendingUp/>} label="Ўқиш фаоллиги" value="—" delta="Дарс натижалари ҳали синхронланмаган"/><Metric icon={<Wallet/>} label="Тасдиқланган тушум" value="$ 0.00" delta="Ҳақиқий тўловлар ҳали уланмаган"/></div>
      <div className="admin-columns"><div className="admin-panel-card"><div className="panel-title"><div><span className="eyebrow">LEARNING PROGRAMS</span><h2>Учебные направления</h2></div><button className="small-action" onClick={()=>setTab("courses")}>Все курсы <ArrowRight size={14}/></button></div><div className="program-line"><div className="program-icon">اقرأ</div><div className="program-text"><b>Мабдаъул Қироат</b><small>Книги 1, 2 и 3 · чтение</small></div><strong>3 курса</strong></div><div className="program-line"><div className="program-icon gold-icon">نحو</div><div className="program-text"><b>Наҳв ва Сарф</b><small>Грамматика · начальный и средний уровни</small></div><strong>4 курса</strong></div></div><div className="admin-panel-card"><div className="panel-title"><div><span className="eyebrow">QUICK ACTIONS</span><h2>Быстрые действия</h2></div></div><button className="quick-action" onClick={()=>{setTab("courses");setShowAdd(true)}}><Plus size={17}/> Добавить новый курс</button><button className="quick-action" onClick={()=>setTab("content")}><ClipboardList size={17}/> Управлять материалами</button><button className="quick-action" onClick={()=>setTab("students")}><Users size={17}/> Посмотреть учеников</button><button className="quick-action" onClick={()=>setTab("payments")}><Wallet size={17}/> Проверить платежи</button></div></div>
    </>}
    {tab === "courses" && <div className="admin-panel-card"><div className="panel-title"><div><span className="eyebrow">COURSE MANAGEMENT</span><h2>Управление курсами</h2></div><button className="primary-button admin-primary" onClick={()=>setShowAdd(!showAdd)}><Plus size={15}/> Добавить курс</button></div>{showAdd && <div className="add-course-form"><input value={courseName} onChange={e=>setCourseName(e.target.value)} placeholder="Название нового курса"/><button className="primary-button admin-primary" onClick={addCourse} disabled={savingCourse}>{savingCourse ? "Сақланмоқда..." : "Сохранить"}</button></div>}{notice && <p className="admin-notice">{notice}</p>}<div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Название курса</th><th>Направление</th><th>Уроки</th><th>Статус</th></tr></thead><tbody>{courses.map(c=><tr key={c.id}><td><b>{c.title}</b><small>{c.level}</small></td><td>{c.program}</td><td>{c.lessons}</td><td><span className="status-pill draft">Черновик</span></td></tr>)}</tbody></table></div><p className="demo-note">Курслар ҳозирча намунавий рўйхат. Янги курс фақат Supabase уланган ва админ рухсати текширилганида доимий сақланади; акс ҳолда демо сессияда қолади.</p></div>}
    {tab === "students" && <DataPanel eyebrow="STUDENT DIRECTORY" title="Ученики" heads={["Ученик","Язык","Курсы","Статус"]} rows={[]} note="Ҳозирча ўқувчилар рўйхати базага уланмаган. Бу ерда фақат ҳақиқий рўйхатдан ўтган аккаунтлар кўрсатилади."/>}
    {tab === "teachers" && <DataPanel eyebrow="TEACHER MANAGEMENT" title="Преподаватели" heads={["Преподаватель","Специализация","Курсы","Статус"]} rows={[]} note="Ўқитувчиларни таклиф қилиш ва курсларга бириктириш функцияси ҳали уланмаган. Ҳақиқий маълумот бўлмагани учун сохта ходимлар кўрсатилмайди."/>}
    {tab === "payments" && <div className="admin-panel-card"><div className="panel-title"><div><span className="eyebrow">PAYMENT CONTROL</span><h2>Буюртмалар ва тўловлар</h2></div></div>{notice && <p className="admin-notice">{notice}</p>}<div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>№</th><th>Маҳсулот</th><th>Сумма</th><th>Изоҳ</th><th>Ҳолат</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td>{o.id.slice(0,8).toUpperCase()}<small>{new Date(o.created_at).toLocaleDateString()}</small></td><td>{o.product_code}</td><td>{formatPrice({price_amount:o.amount,currency:o.currency})}</td><td>{o.payer_note ?? "—"}</td><td>{o.status === "pending" ? <button className="small-action" onClick={()=>onConfirm(o.id)}>Тўлов келди — очиш</button> : <span className="status-pill draft">{o.status}</span>}</td></tr>)}</tbody></table></div>{orders.length===0 && <p className="demo-note">Ҳозирча буюртма йўқ (ёки Supabase уланмаган). Тўлов фақат ҳақиқий пул келганини текшириб, шу ердан тасдиқланади.</p>}</div>}
    {tab === "content" && <DataPanel eyebrow="CONTENT LIBRARY" title="Учебные материалы" heads={["Тип","Поддержка","Хранилище","Состояние"]} rows={[["Текст урока","Узбекский / Кыргызский / Русский","База данных","Схема готова"],["Аудио","MP3 / M4A","Object Storage","Не подключено"],["PDF","Учебники и конспекты","Object Storage","Не подключено"],["Видео","MP4 / потоковое видео","Object Storage","Не подключено"]]} note="Панель предусматривает загрузку и привязку учебных материалов к урокам после настройки защищённого хранилища."/>}
  </section>;
}
function Metric({icon,label,value,delta}:{icon:ReactNode,label:string,value:string,delta:string}) { return <div className="metric-card"><div className="metric-icon">{icon}</div><span>{label}</span><b>{value}</b><small>{delta}</small></div>; }
function DataPanel({eyebrow,title,heads,rows,note}:{eyebrow:string,title:string,heads:string[],rows:string[][],note:string}) { return <div className="admin-panel-card"><div className="panel-title"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div><button className="small-action"><Download size={14}/> Экспорт</button></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr>{heads.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{r.map((v,j)=><td key={j}>{j===r.length-1?<span className="status-pill draft">{v}</span>:v}</td>)}</tr>)}</tbody></table></div><p className="demo-note">{note}</p></div>; }

function CourseCard({course,onClick,t}:{course:typeof courses[number],onClick:()=>void,t:typeof translations.uz}) {
  return <button className="course-card" onClick={onClick}><div className={`course-cover ${course.color}`}><span className="course-category">{course.category}</span><div className="cover-glyph">اَلْعِلْمُ</div><span className="cover-level">{course.level}</span></div><div className="course-body"><h3>{course.title}</h3><p>{course.description}</p><div className="course-meta"><span><BookOpen size={14}/>{course.lessons > 0 ? `${course.lessons} ${t.lessons}` : "Дарслар тайёрланмоқда"}</span><span><Clock3 size={14}/>{course.duration}</span></div><div className="progress-track"><span style={{width:`${course.progress}%`}}/></div><div className="course-bottom"><span>{course.progress ? `${course.progress}%` : course.lessons > 0 ? "Намуна очиқ" : "Тайёрланмоқда"}</span><span className="start-link">{t.start}<ArrowRight size={14}/></span></div></div></button>;
}
function EmptyPage({icon,title,desc}:{icon:ReactNode,title:string,desc:string}) {
  return <div className="empty-page"><div className="empty-icon">{icon}</div><span className="eyebrow">COMING IN THE NEXT RELEASE</span><h1>{title}</h1><p>{desc}</p><span className="pill">MVP · IN DEVELOPMENT</span></div>;
}
