import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { GraduationCap, ShieldCheck, LoaderCircle } from 'lucide-react';
import { supabase } from './lib/supabase';
import { getAcademyRole, type AcademyRole, type AuthState } from './lib/auth';

export default function AuthGate({ children }: { children: (auth: AuthState & { role: AcademyRole }) => ReactNode }) {
  const [session, setSession] = useState<AuthState['session']>(null);
  const [role, setRole] = useState<AcademyRole>('student');
  const [loading, setLoading] = useState(Boolean(supabase));
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const sessionCheck = Promise.race([
      supabase.auth.getSession(),
      new Promise<never>((_, reject) => window.setTimeout(() => reject(new Error('Сервер жавоби 10 сония ичида келмади. .env созламаларини текширинг ёки Supabase қийматларини вақтинча бўш қолдиринг.')), 10000)),
    ]);
    sessionCheck.then(async ({ data, error }) => {
      if (!alive) return;
      if (error) setMessage(`Сессияни текширишда хатолик: ${error.message}`);
      setSession(data?.session ?? null);
      if (data?.session?.user) {
        try { setRole(await getAcademyRole(data.session.user.id)); }
        catch { setRole('student'); }
      }
      setLoading(false);
    }).catch((error: unknown) => {
      if (!alive) return;
      setSession(null); setRole('student');
      setMessage(error instanceof Error ? `Серверга уланиб бўлмади: ${error.message}` : 'Серверга уланиб бўлмади.');
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      if (!next) { setRole('student'); setLoading(false); }
      else setTimeout(async () => {
        try { setRole(await getAcademyRole(next.user.id)); } catch { setRole('student'); }
        setLoading(false);
      }, 0);
    });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage('');
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: name } } });
        if (error) throw error;
        if (data.user && !data.session) setMessage('Аккаунт яратилди. Электрон почтангизга юборилган тасдиқлаш ҳаволасини очинг.');
        else if (data.user) {
          await supabase.from('profiles').upsert({ id: data.user.id, display_name: name });
          setMessage('Рўйхатдан ўтдингиз.');
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) { setMessage(err instanceof Error ? err.message : 'Хатолик юз берди.'); }
    finally { setBusy(false); }
  }
  if (!supabase) return <>{children({ session: null, user: null, role: 'student' })}</>;
  if (loading) return <div className="auth-screen"><LoaderCircle className="spin"/><p>ILM ACADEMY юкланмоқда...</p></div>;
  if (session?.user) return <>{children({ session, user: session.user, role })}</>;
  return <div className="auth-screen"><form className="auth-card" onSubmit={submit}>
    <div className="auth-logo"><GraduationCap size={28}/></div><span className="eyebrow">ILM ACADEMY PRO</span>
    <h1>{mode === 'login' ? 'Хуш келибсиз' : 'Аккаунт яратинг'}</h1><p>Илм йўлидаги таълим платформасига киринг.</p>
    {mode === 'signup' && <label>Исмингиз<input value={name} onChange={e=>setName(e.target.value)} required placeholder="Исм ва фамилия"/></label>}
    <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="you@example.com"/></label>
    <label>Пароль<input type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required placeholder="Камида 8 белги"/></label>
    {message && <div className="auth-message">{message}</div>}
    <button className="primary-button auth-submit" disabled={busy}>{busy ? 'Кутинг...' : mode === 'login' ? 'Кириш' : 'Рўйхатдан ўтиш'}</button>
    <button type="button" className="auth-switch" onClick={()=>{setMode(mode==='login'?'signup':'login');setMessage('')}}>{mode==='login'?'Аккаунтингиз йўқми? Рўйхатдан ўтинг':'Аккаунтингиз борми? Киринг'}</button>
    <small><ShieldCheck size={13}/> Аккаунтлар Supabase Auth орқали ҳимояланади.</small>
  </form></div>;
}
