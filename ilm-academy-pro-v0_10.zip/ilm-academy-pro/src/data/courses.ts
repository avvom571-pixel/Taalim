export type Course = {
  id: string;
  title: string;
  category: string;
  level: string;
  lessons: number;
  duration: string;
  description: string;
  color: string;
  progress: number;
  program: string;
};

// Lesson counts reflect content currently present in this build, not the future syllabus.
export const courses: Course[] = [
  { id: "mabda-1", title: "Мабдаъул Қироат — 1-китоб", category: "Қироат", level: "Бошланғич", lessons: 1, duration: "143 саҳифа · PDF", description: "Китобнинг 143 саҳифали PDF нусхаси: таништув қисми очиқ, тўлиқ нусха ёпиқ сақланади ва фақат рухсати борларга очилади.", color: "mint", progress: 0, program: "Мабдаъул Қироат" },
  { id: "mabda-2", title: "Мабдаъул Қироат — 2-китоб", category: "Қироат", level: "Бошланғич+", lessons: 1, duration: "158 саҳифа · PDF", description: "Китобнинг 158 саҳифали PDF нусхаси: таништув қисми очиқ, тўлиқ нусха ёпиқ сақланади ва фақат рухсати борларга очилади.", color: "sand", progress: 0, program: "Мабдаъул Қироат" },
  { id: "mabda-3", title: "Мабдаъул Қироат — 3-китоб", category: "Қироат", level: "Ўрта", lessons: 115, duration: "57 луғат дарси · 819 сўз · 58 матн", description: "57 луғат дарсидаги 819 та сўз (карточкалар ва тест) ҳамда 58 та арабча ўқиш матни ўзбекча таржимаси билан. Дастлабки 5 луғат ва 3 матн бепул.", color: "lavender", progress: 0, program: "Мабдаъул Қироат" },
  { id: "nahw-intro", title: "Наҳв илмига кириш", category: "Грамматика", level: "Бошланғич", lessons: 3, duration: "Намуна дарслар", description: "Калом, исм-феъл-ҳарф ва исм аломатлари бўйича 3 та текширув талаб қиладиган намунавий дарс.", color: "blue", progress: 0, program: "Наҳв ва Сарф" },
  { id: "nahw-advanced", title: "Наҳв: иъроб ва жумлалар", category: "Грамматика", level: "Ўрта", lessons: 8, duration: "8 дарс · тестлар билан", description: "Иъроб, фоил, мубтадаъ-хабар, мафъул, жар ва изофа, кана ва инна. 1-дарс бепул.", color: "mint", progress: 0, program: "Наҳв ва Сарф" },
  { id: "sarf-intro", title: "Сарф илмига кириш", category: "Грамматика", level: "Бошланғич", lessons: 2, duration: "Намуна дарслар", description: "Сарфнинг вазифаси, илдиз-вазн, мозий ва музореъ бўйича 2 та намунавий дарс.", color: "sand", progress: 0, program: "Наҳв ва Сарф" },
  { id: "sarf-advanced", title: "Сарф: феъллар таҳлили", category: "Грамматика", level: "Ўрта", lessons: 8, duration: "8 дарс · тестлар билан", description: "Феъл турлари, олти боб, масдар, исми фоил/мафъул, амр, мазид феъллар, жамъ ва мозий туслаш. 1-дарс бепул.", color: "lavender", progress: 0, program: "Наҳв ва Сарф" }
];
