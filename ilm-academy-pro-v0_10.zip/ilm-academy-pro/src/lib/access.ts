import { supabase } from "./supabase";

export type Product = { code: string; title: string; kind: "course" | "plan"; course_ids: string[]; price_amount: number; currency: string; duration_days: number | null };

// Shown when the database is not connected (demo). Real prices come from public.products.
export const FALLBACK_PRODUCTS: Product[] = [
  { code: "course-mabda-3", title: "Мабдаъул Қироат 3 — тўлиқ интерактив курс", kind: "course", course_ids: ["mabda-3"], price_amount: 799, currency: "USD", duration_days: null },
  { code: "plan-standard", title: "Standard — ойлик", kind: "plan", course_ids: ["mabda-3", "nahw-intro", "nahw-advanced", "sarf-intro", "sarf-advanced"], price_amount: 399, currency: "USD", duration_days: 30 },
  { code: "plan-premium", title: "Premium — ойлик", kind: "plan", course_ids: ["mabda-3", "nahw-intro", "nahw-advanced", "sarf-intro", "sarf-advanced"], price_amount: 699, currency: "USD", duration_days: 30 },
];

export const formatPrice = (p: Pick<Product, "price_amount" | "currency">) => `${p.currency === "USD" ? "$" : p.currency + " "}${(p.price_amount / 100).toFixed(2)}`;

export async function loadProducts(): Promise<Product[]> {
  if (!supabase) return FALLBACK_PRODUCTS;
  const { data, error } = await supabase.from("products").select("code,title,kind,course_ids,price_amount,currency,duration_days").eq("active", true).order("price_amount");
  if (error || !data?.length) return FALLBACK_PRODUCTS;
  return data as Product[];
}

export async function loadUnlockedCourses(): Promise<string[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.rpc("my_unlocked_courses");
  if (error) return [];
  return (data as string[] | null) ?? [];
}

export async function createOrder(productCode: string, note: string): Promise<string> {
  if (!supabase) throw new Error("Сервер (Supabase) уланмаган — буюртма яратиб бўлмайди.");
  const { data, error } = await supabase.rpc("create_order", { p_product_code: productCode, p_note: note || null });
  if (error) throw error;
  return data as string;
}

export type OrderRow = { id: string; user_id: string; product_code: string; amount: number; currency: string; status: string; payer_note: string | null; created_at: string };
export async function loadOrders(): Promise<OrderRow[]> {
  if (!supabase) return [];
  const { data } = await supabase.from("orders").select("id,user_id,product_code,amount,currency,status,payer_note,created_at").order("created_at", { ascending: false }).limit(100);
  return (data as OrderRow[] | null) ?? [];
}
export async function fulfilOrder(orderId: string): Promise<void> {
  if (!supabase) throw new Error("Supabase уланмаган.");
  const { error } = await supabase.rpc("fulfil_order", { p_order_id: orderId, p_source: "admin_grant", p_reference: null });
  if (error) throw error;
}
