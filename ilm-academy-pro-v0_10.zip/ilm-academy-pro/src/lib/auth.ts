import type { Session, User } from '@supabase/supabase-js';
import { supabase } from './supabase';

export type AcademyRole = 'student' | 'teacher' | 'admin' | 'super_admin';
export async function getAcademyRole(userId: string): Promise<AcademyRole> {
  if (!supabase) return 'student';
  const { data, error } = await supabase.from('user_roles').select('role').eq('user_id', userId);
  if (error) throw error;
  const roles = (data ?? []).map((row: { role: string }) => row.role);
  if (roles.includes('super_admin')) return 'super_admin';
  if (roles.includes('admin')) return 'admin';
  if (roles.includes('teacher')) return 'teacher';
  return 'student';
}
export type AuthState = { session: Session | null; user: User | null };
