import { supabase } from "./supabase";

const LS_KEY = "ilm-progress-v1";
type Store = Record<string, { courseId: string; done: boolean; score?: number }>;
const readLocal = (): Store => { try { return JSON.parse(localStorage.getItem(LS_KEY) ?? "{}") as Store; } catch { return {}; } };
const writeLocal = (s: Store) => { try { localStorage.setItem(LS_KEY, JSON.stringify(s)); } catch { /* storage blocked */ } };

export async function loadProgress(userId?: string): Promise<Store> {
  const local = readLocal();
  if (!supabase || !userId) return local;
  const { data } = await supabase.from("user_progress").select("lesson_key,course_id,completed_at,best_score").eq("user_id", userId);
  const merged: Store = { ...local };
  for (const r of (data ?? []) as Array<{ lesson_key: string; course_id: string; completed_at: string | null; best_score: number | null }>) {
    merged[r.lesson_key] = { courseId: r.course_id, done: Boolean(r.completed_at) || merged[r.lesson_key]?.done === true, score: Math.max(r.best_score ?? 0, merged[r.lesson_key]?.score ?? 0) || undefined };
  }
  return merged;
}

export async function saveProgress(userId: string | undefined, lessonKey: string, courseId: string, done: boolean, score?: number): Promise<Store> {
  const store = readLocal();
  const prev = store[lessonKey];
  store[lessonKey] = { courseId, done: done || prev?.done === true, score: Math.max(score ?? 0, prev?.score ?? 0) || undefined };
  writeLocal(store);
  if (supabase && userId) {
    await supabase.from("user_progress").upsert({ user_id: userId, lesson_key: lessonKey, course_id: courseId, completed_at: store[lessonKey].done ? new Date().toISOString() : null, best_score: store[lessonKey].score ?? null, updated_at: new Date().toISOString() });
  }
  return store;
}
