import metaJson from "../data/mabda3-meta.json";
import freeJson from "../data/mabda3-free.json";
import { supabase } from "./supabase";

export type LessonMeta = { key: string; kind: "vocab" | "text"; n: number; title: string; arTitle?: string; count: number; free: boolean };
export type VocabItem = { ar: string; uz: string };
export type VocabData = { items: VocabItem[] };
export type TextData = { uzTitle: string; arTitle: string; pairs: { ar: string; uz: string }[] };
export type LessonData = VocabData | TextData;

export const mabda3Meta = metaJson as LessonMeta[];
const freeContent = freeJson as unknown as Record<string, LessonData>;

export type LoadResult = { ok: true; data: LessonData } | { ok: false; reason: "locked" | "offline" | "error"; message: string };

// Free lessons ship with the app; paid lessons are fetched from the database and only returned if the account is entitled (RLS).
export async function loadMabda3Lesson(key: string): Promise<LoadResult> {
  if (freeContent[key]) return { ok: true, data: freeContent[key] };
  if (!supabase) return { ok: false, reason: "offline", message: "Тўлиқ дарс базадан юкланади. Supabase уланмаган." };
  const { data, error } = await supabase.from("paid_content").select("data").eq("course_id", "mabda-3").eq("lesson_key", key).maybeSingle();
  if (error) return { ok: false, reason: "error", message: error.message };
  if (!data) return { ok: false, reason: "locked", message: "Бу дарс пуллик. Очиш учун тарифни танланг." };
  return { ok: true, data: data.data as LessonData };
}

// ---- Generic text lessons (Nahw / Sarf advanced) ----
import lessonsMetaJson from "../data/lessons-meta.json";
import lessonsFreeJson from "../data/lessons-free.json";
export type CourseLessonMeta = { courseId: string; key: string; n: number; title: string; free: boolean; count: number };
export type CourseLessonData = { intro: string; sections: { heading: string; body: string; arabic?: string; example?: string }[]; questions: { prompt: string; options: string[]; answer: number; explain: string }[]; source: string };
export const courseLessonMeta = lessonsMetaJson as CourseLessonMeta[];
const lessonsFree = lessonsFreeJson as unknown as Record<string, CourseLessonData>;
export async function loadCourseLesson(courseId: string, key: string): Promise<{ ok: true; data: CourseLessonData } | { ok: false; message: string }> {
  const local = lessonsFree[`${courseId}/${key}`];
  if (local) return { ok: true, data: local };
  if (!supabase) return { ok: false, message: "Тўлиқ дарс базадан юкланади. Supabase уланмаган." };
  const { data, error } = await supabase.from("paid_content").select("data").eq("course_id", courseId).eq("lesson_key", key).maybeSingle();
  if (error) return { ok: false, message: error.message };
  if (!data) return { ok: false, message: "Бу дарс пуллик. Очиш учун тарифни танланг." };
  return { ok: true, data: data.data as CourseLessonData };
}
