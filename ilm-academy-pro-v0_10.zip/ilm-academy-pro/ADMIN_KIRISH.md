# Админ-панелга қандай кириш

Админ-панел фақат **Supabase уланганда** ишлайди (демо режимда у йўқ).

1. Supabase лойиҳасида SQL файлларни тартиб билан ишга туширинг: `schema.sql`, `v0.2-admin-migration.sql`, `v0.3-security-auth.sql`, `v0.8-monetization.sql`, `v0.9-payments-server.sql`, кейин `seed-mabda3-content.sql` ва `seed-lessons.sql`.
2. `.env` да `VITE_SUPABASE_URL` ва `VITE_SUPABASE_ANON_KEY` ни ёзинг (service_role ни ҳеч қачон ёзманг). `npm run dev`.
3. Сайтда ўз почтангиз билан **рўйхатдан ўтинг** ва кириш.
4. Supabase → Authentication → Users дан ўз UUID'ингизни нусхаланг, SQL Editor'да:
   `insert into public.user_roles(user_id, role) values ('СИЗНИНГ-UUID', 'super_admin') on conflict do nothing;`
5. Сайтдан чиқиб, қайта киринг. Чап менюда **«Админ-панель»** пайдо бўлади. «Платежи» бўлимида буюртмалар ва «Тўлов келди — очиш» тугмаси бор.
