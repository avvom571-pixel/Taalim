# v0.9 — автоматик тўлов (сервер қисми)

Тайёр: `create-checkout` (буюртма бўйича провайдер саҳифасига ўтказади), `payment-webhook` (имзони текширади, такрорий хабарни рад этади, суммани базадаги буюртма билан солиштиради, `fulfil_order` орқали premium очади), муддат тугаганда рухсат ўзи ёпилади, қайта тўлов муддатни узайтиради.
Карта рақами сайтда ҳеч қачон киритилмайди — фақат провайдер саҳифасида.

## Провайдер уланганда
1. `supabase/v0.9-payments-server.sql` ни ишга туширинг.
2. `supabase/functions/_shared/provider.ts` ичидаги 2 функцияни провайдер ҳужжати бўйича тўлдиринг (шу ерда ёзилмагани учун ҳозир улар хато беради).
3. `supabase functions deploy create-checkout` ва `supabase functions deploy payment-webhook --no-verify-jwt`; secrets: `SITE_URL`, `PAYMENT_PROVIDER`, провайдер калитлари. `SUPABASE_SERVICE_ROLE_KEY` фақат сервер secrets'да, ҳеч қачон `.env` да эмас.
4. Webhook URL'ни провайдер кабинетига киритинг, тест тўловини ўтказинг, кейин `VITE_CHECKOUT_ENABLED=true`.
