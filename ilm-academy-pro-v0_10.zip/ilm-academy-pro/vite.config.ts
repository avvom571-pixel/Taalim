import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Relative asset paths work for localhost, static previews and Capacitor builds.
export default defineConfig({
  base: "./",
  plugins: [react()],
});
