// >>> THE ONLY PROVIDER-SPECIFIC FILE <<<
// Fill the two functions below from your payment provider's official documentation
// (GoPay / MPO.KG / Paymaster / other) AFTER you have a signed merchant agreement and test keys.
// Until then both throw, so no payment can be faked or accepted by accident.

export type CheckoutInput = { orderId: string; amount: number; currency: string; title: string; returnUrl: string };
export type ParsedEvent = { eventId: string; orderId: string; status: "paid" | "failed"; amount: number; currency: string; reference: string };

/** Ask the provider for a hosted payment page; return its URL. Card data is entered ONLY on the provider's page. */
export async function createCheckoutUrl(_input: CheckoutInput): Promise<string> {
  throw new Error("PROVIDER_NOT_CONFIGURED: implement createCheckoutUrl() from the provider's API docs.");
}

/** Verify the provider's webhook signature on the RAW body (exact scheme is in their docs) and map it to ParsedEvent.
 *  Must throw if the signature is invalid. `amount` is in minor units (cents/tiyin) to match public.orders.amount. */
export async function verifyAndParse(_req: Request, _rawBody: string): Promise<ParsedEvent> {
  throw new Error("PROVIDER_NOT_CONFIGURED: implement verifyAndParse() with signature verification.");
}
