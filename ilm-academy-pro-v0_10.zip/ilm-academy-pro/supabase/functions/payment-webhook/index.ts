import { createClient } from "npm:@supabase/supabase-js@2";
import { verifyAndParse } from "../_shared/provider.ts";

// Deploy with:  supabase functions deploy payment-webhook --no-verify-jwt   (the provider has no Supabase JWT;
// authenticity comes ONLY from the provider signature checked in verifyAndParse).
Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  const raw = await req.text();
  let ev;
  try { ev = await verifyAndParse(req, raw); } catch { return new Response("invalid signature", { status: 401 }); }

  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const provider = Deno.env.get("PAYMENT_PROVIDER") ?? "provider";

  // Idempotency: a repeated event is acknowledged but not processed twice.
  const { error: dup } = await db.from("payment_events").insert({ provider, event_id: ev.eventId, payload: JSON.parse(raw) });
  if (dup) return new Response("duplicate", { status: 200 });

  const { data: order } = await db.from("orders").select("id,status,amount,currency").eq("id", ev.orderId).maybeSingle();
  if (!order) return new Response("unknown order", { status: 404 });

  if (ev.status === "paid") {
    // Never trust the amount the client or a redirect claims: it must equal the order stored in OUR database.
    if (ev.amount !== order.amount || ev.currency !== order.currency) return new Response("amount mismatch", { status: 422 });
    const { error } = await db.rpc("fulfil_order", { p_order_id: order.id, p_source: "web_payment", p_reference: ev.reference });
    if (error) return new Response("fulfil failed", { status: 500 });   // provider will retry
  } else if (order.status === "pending") {
    await db.from("orders").update({ status: "failed" }).eq("id", order.id);
  }
  return new Response("ok", { status: 200 });
});
