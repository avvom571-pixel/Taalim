import { createClient } from "npm:@supabase/supabase-js@2";
import { createCheckoutUrl } from "../_shared/provider.ts";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { orderId } = await req.json();
    // Run as the signed-in user: RLS guarantees they can only read their own order.
    const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
    const { data: order, error } = await db.from("orders").select("id,status,amount,currency,product_code").eq("id", orderId).maybeSingle();
    if (error || !order) return json({ error: "order not found" }, 404);
    if (order.status !== "pending") return json({ error: "order is not pending" }, 409);
    const { data: product } = await db.from("products").select("title").eq("code", order.product_code).maybeSingle();
    const url = await createCheckoutUrl({ orderId: order.id, amount: order.amount, currency: order.currency, title: product?.title ?? order.product_code, returnUrl: Deno.env.get("SITE_URL") ?? "" });
    return json({ url });
  } catch (e) { return json({ error: e instanceof Error ? e.message : "error" }, 500); }
});
