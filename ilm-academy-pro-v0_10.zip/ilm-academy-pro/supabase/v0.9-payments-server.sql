-- Lets the payment-webhook Edge Function (service role) mark orders paid. Run after v0.8.
grant execute on function public.fulfil_order(uuid, text, text) to service_role;

-- Renewal: if the user already has an active plan of the same product, the new period starts when the old one ends.
create or replace function public.fulfil_order(p_order_id uuid, p_source text default 'admin_grant', p_reference text default null)
returns void language plpgsql security definer set search_path = public as $$
declare o public.orders; prod public.products; base timestamptz;
begin
  if auth.uid() is not null and not public.has_academy_role(array['admin','super_admin']) then
    raise exception 'admin only';
  end if;
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  if o.status = 'paid' then return; end if;
  select * into prod from public.products where code = o.product_code;
  select greatest(now(), coalesce(max(ends_at), now())) into base from public.entitlements
    where user_id = o.user_id and product_code = o.product_code and status = 'active' and ends_at is not null;
  update public.orders set status='paid', paid_at=now(), external_reference=coalesce(p_reference, external_reference) where id = o.id;
  insert into public.entitlements(user_id, product_code, source, status, starts_at, ends_at, external_reference)
  values (o.user_id, o.product_code, case when p_source in ('google_play','web_payment','admin_grant','coupon') then p_source else 'admin_grant' end,
          'active', now(), case when prod.duration_days is null then null else base + make_interval(days => prod.duration_days) end, coalesce(p_reference, o.id::text));
  insert into public.audit_logs(actor_id, action, entity_type, entity_id, metadata)
  values (auth.uid(), 'fulfil_order', 'orders', o.id::text, jsonb_build_object('product', o.product_code, 'source', p_source));
end $$;
revoke all on function public.fulfil_order(uuid,text,text) from public;
grant execute on function public.fulfil_order(uuid,text,text) to authenticated, service_role;
