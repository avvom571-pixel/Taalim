-- ILM ACADEMY PRO v0.2: administration, teaching staff, exams and certificates.
-- Run after schema.sql in Supabase SQL Editor.

create table if not exists public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('student','teacher','admin','super_admin')),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

create table if not exists public.programs (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.program_translations (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references public.programs(id) on delete cascade,
  language text not null check (language in ('uz','ky','ru')),
  title text not null,
  description text not null default '',
  unique(program_id, language)
);

alter table public.courses add column if not exists program_id uuid references public.programs(id);
alter table public.courses add column if not exists price_cents integer not null default 0 check (price_cents >= 0);
alter table public.courses add column if not exists teacher_id uuid references auth.users(id);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  pass_percent integer not null default 70 check (pass_percent between 1 and 100),
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  position integer not null,
  question jsonb not null,
  options jsonb not null default '[]'::jsonb,
  answer_key text not null,
  explanation jsonb not null default '{}'::jsonb,
  unique(quiz_id, position)
);

create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  certificate_code text unique not null,
  issued_at timestamptz not null default now(),
  final_score numeric(5,2),
  unique(user_id, course_id)
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title jsonb not null,
  body jsonb not null,
  published boolean not null default false,
  published_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.has_academy_role(required_roles text[])
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = any(required_roles)
  );
$$;

alter table public.user_roles enable row level security;
alter table public.programs enable row level security;
alter table public.program_translations enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.certificates enable row level security;
alter table public.announcements enable row level security;
alter table public.audit_logs enable row level security;

create policy "roles_read_self_or_admin" on public.user_roles for select to authenticated
using (user_id = auth.uid() or public.has_academy_role(array['admin','super_admin']));
create policy "admins_manage_roles" on public.user_roles for all to authenticated
using (public.has_academy_role(array['super_admin']))
with check (public.has_academy_role(array['super_admin']));

create policy "published_programs_read" on public.programs for select
using (exists (select 1 from public.courses c where c.program_id = id and c.status = 'published'));
create policy "admins_manage_programs" on public.programs for all to authenticated
using (public.has_academy_role(array['admin','super_admin']))
with check (public.has_academy_role(array['admin','super_admin']));
create policy "program_translations_read" on public.program_translations for select
using (exists (select 1 from public.programs p where p.id = program_id));
create policy "admins_manage_program_translations" on public.program_translations for all to authenticated
using (public.has_academy_role(array['admin','super_admin']))
with check (public.has_academy_role(array['admin','super_admin']));

create policy "admins_manage_courses" on public.courses for all to authenticated
using (public.has_academy_role(array['admin','super_admin']) or (public.has_academy_role(array['teacher']) and teacher_id = auth.uid()))
with check (public.has_academy_role(array['admin','super_admin']) or (public.has_academy_role(array['teacher']) and teacher_id = auth.uid()));
create policy "admins_manage_course_translations" on public.course_translations for all to authenticated
using (public.has_academy_role(array['admin','super_admin']))
with check (public.has_academy_role(array['admin','super_admin']));
create policy "staff_manage_lessons" on public.lessons for all to authenticated
using (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid() and public.has_academy_role(array['teacher'])))
with check (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid() and public.has_academy_role(array['teacher'])));
create policy "staff_manage_lesson_translations" on public.lesson_translations for all to authenticated
using (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.lessons l join public.courses c on c.id=l.course_id where l.id=lesson_id and c.teacher_id=auth.uid() and public.has_academy_role(array['teacher'])))
with check (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.lessons l join public.courses c on c.id=l.course_id where l.id=lesson_id and c.teacher_id=auth.uid() and public.has_academy_role(array['teacher'])));

create policy "published_quizzes_read" on public.quizzes for select using (published = true);
create policy "staff_manage_quizzes" on public.quizzes for all to authenticated
using (public.has_academy_role(array['admin','super_admin','teacher']))
with check (public.has_academy_role(array['admin','super_admin','teacher']));
create policy "published_quiz_questions_read" on public.quiz_questions for select
using (exists (select 1 from public.quizzes q where q.id = quiz_id and q.published = true));
create policy "staff_manage_quiz_questions" on public.quiz_questions for all to authenticated
using (public.has_academy_role(array['admin','super_admin','teacher']))
with check (public.has_academy_role(array['admin','super_admin','teacher']));

create policy "certificates_read_own_or_admin" on public.certificates for select to authenticated
using (user_id = auth.uid() or public.has_academy_role(array['admin','super_admin','teacher']));
create policy "admins_issue_certificates" on public.certificates for insert to authenticated
with check (public.has_academy_role(array['admin','super_admin']));
create policy "published_announcements_read" on public.announcements for select using (published = true);
create policy "admins_manage_announcements" on public.announcements for all to authenticated
using (public.has_academy_role(array['admin','super_admin']))
with check (public.has_academy_role(array['admin','super_admin']));
create policy "admins_read_audit_logs" on public.audit_logs for select to authenticated
using (public.has_academy_role(array['admin','super_admin']));
create policy "admins_write_audit_logs" on public.audit_logs for insert to authenticated
with check (public.has_academy_role(array['admin','super_admin']));

-- IMPORTANT: assign the first super_admin manually after creating its auth user:
-- insert into public.user_roles(user_id, role) values ('AUTH-USER-UUID', 'super_admin');
-- Do not expose service_role keys to browser/mobile clients. Validate payments on trusted server only.
