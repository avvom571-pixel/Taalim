-- ILM ACADEMY PRO v0.8: products, orders, paid access, progress by lesson key, private book storage.
-- Run AFTER schema.sql, v0.2-admin-migration.sql and v0.3-security-auth.sql.
-- Safe to re-run.

-- 1) Products (what can be sold). Prices are editable by admins; amounts in minor units (tiyin/cents).
create table if not exists public.products (
  code text primary key,                       -- e.g. 'course-mabda-3', 'plan-standard'
  title text not null,
  kind text not null check (kind in ('course','plan')),
  course_ids text[] not null default '{}',     -- app course ids unlocked (e.g. {'mabda-3'})
  price_amount integer not null check (price_amount >= 0),
  currency text not null default 'USD',
  duration_days integer,                       -- null = lifetime (one-time course)
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;
drop policy if exists products_read_active on public.products;
create policy products_read_active on public.products for select using (active = true);
drop policy if exists products_admin_manage on public.products;
create policy products_admin_manage on public.products for all to authenticated
  using (public.has_academy_role(array['admin','super_admin'])) with check (public.has_academy_role(array['admin','super_admin']));

insert into public.products(code,title,kind,course_ids,price_amount,currency,duration_days,active) values
  ('course-mabda-3','Мабдаъул Қироат 3 — интерактив луғат ва матнлар','course','{mabda-3}',799,'USD',null,true),
  ('plan-standard','Standard (ойлик)','plan','{mabda-3,nahw-intro,nahw-advanced,sarf-intro,sarf-advanced}',399,'USD',30,true),
  ('plan-premium','Premium (ойлик)','plan','{mabda-3,nahw-intro,nahw-advanced,sarf-intro,sarf-advanced}',699,'USD',30,true),
  -- Book PDFs (arabic.uz): keep INACTIVE until the publisher/author gives written permission to sell or distribute them.
  ('course-mabda-1','Мабдаъул Қироат — 1-китоб (PDF)','course','{mabda-1}',799,'USD',null,false),
  ('course-mabda-2','Мабдаъул Қироат — 2-китоб (PDF)','course','{mabda-2}',799,'USD',null,false)
on conflict (code) do nothing;
-- NOTE: these are the test-price hypotheses from BUSINESS_MODEL.md, not confirmed market prices.

-- 2) Orders. Created by the client as 'pending'; ONLY a trusted server/webhook or an admin can mark them 'paid'.
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_code text not null references public.products(code),
  amount integer not null,
  currency text not null,
  provider text not null default 'manual',     -- 'manual' | 'gopay' | 'mpo' | 'paymaster' ...
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded','cancelled')),
  external_reference text,
  payer_note text,                             -- what the payer wrote (e.g. transfer sender / last digits) for manual matching
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index if not exists orders_user_idx on public.orders(user_id, created_at desc);
alter table public.orders enable row level security;
drop policy if exists orders_read_own on public.orders;
create policy orders_read_own on public.orders for select to authenticated using (user_id = auth.uid());
drop policy if exists orders_admin_read on public.orders;
create policy orders_admin_read on public.orders for select to authenticated using (public.has_academy_role(array['admin','super_admin']));
-- no insert/update policies on purpose: all writes go through the functions below.

-- 3) Raw provider events (idempotency + audit). Written only by the webhook Edge Function (service role).
create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  event_id text not null,
  payload jsonb not null,
  received_at timestamptz not null default now(),
  unique(provider, event_id)
);
alter table public.payment_events enable row level security;  -- no policies: invisible to clients

-- 4) Client creates a pending order (price is read from products, never from the client).
create or replace function public.create_order(p_product_code text, p_note text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare prod public.products; oid uuid;
begin
  if auth.uid() is null then raise exception 'login required'; end if;
  select * into prod from public.products where code = p_product_code and active = true;
  if not found then raise exception 'unknown product'; end if;
  insert into public.orders(user_id, product_code, amount, currency, payer_note)
  values (auth.uid(), prod.code, prod.price_amount, prod.currency, left(p_note, 300)) returning id into oid;
  return oid;
end $$;
revoke all on function public.create_order(text,text) from public;
grant execute on function public.create_order(text,text) to authenticated;

-- 5) Mark order paid + grant access. Used by admins (manual bank/wallet transfer) and, via service role, by the webhook.
create or replace function public.fulfil_order(p_order_id uuid, p_source text default 'admin_grant', p_reference text default null)
returns void language plpgsql security definer set search_path = public as $$
declare o public.orders; prod public.products;
begin
  if auth.uid() is not null and not public.has_academy_role(array['admin','super_admin']) then
    raise exception 'admin only';
  end if;
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  if o.status = 'paid' then return; end if;           -- idempotent
  select * into prod from public.products where code = o.product_code;
  update public.orders set status='paid', paid_at=now(), external_reference=coalesce(p_reference, external_reference) where id = o.id;
  insert into public.entitlements(user_id, product_code, source, status, starts_at, ends_at, external_reference)
  values (o.user_id, o.product_code, case when p_source in ('google_play','web_payment','admin_grant','coupon') then p_source else 'admin_grant' end,
          'active', now(), case when prod.duration_days is null then null else now() + make_interval(days => prod.duration_days) end, coalesce(p_reference, o.id::text));
  insert into public.audit_logs(actor_id, action, entity_type, entity_id, metadata)
  values (auth.uid(), 'fulfil_order', 'orders', o.id::text, jsonb_build_object('product', o.product_code, 'source', p_source));
end $$;
revoke all on function public.fulfil_order(uuid,text,text) from public;
grant execute on function public.fulfil_order(uuid,text,text) to authenticated;

-- 6) Does the current user have access to a given app course id?  (UI hint only: files are protected separately by storage policies.)
create or replace function public.my_unlocked_courses()
returns text[] language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct c), '{}') from (
    select unnest(p.course_ids) as c
    from public.entitlements e join public.products p on p.code = e.product_code
    where e.user_id = auth.uid() and e.status = 'active' and e.starts_at <= now() and (e.ends_at is null or e.ends_at > now())
  ) s;
$$;
revoke all on function public.my_unlocked_courses() from public;
grant execute on function public.my_unlocked_courses() to authenticated;

-- 7) Progress keyed by the app's lesson key (works for built-in lessons that are not rows in public.lessons).
create table if not exists public.user_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_key text not null,
  course_id text not null,
  completed_at timestamptz,
  best_score numeric(5,2),
  updated_at timestamptz not null default now(),
  primary key (user_id, lesson_key)
);
alter table public.user_progress enable row level security;
drop policy if exists user_progress_own on public.user_progress;
create policy user_progress_own on public.user_progress for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- 8) Private storage for book PDFs: bucket is NOT public; only holders of the matching entitlement may read.
insert into storage.buckets(id, name, public) values ('books','books',false) on conflict (id) do update set public = false;
drop policy if exists books_read_entitled on storage.objects;
create policy books_read_entitled on storage.objects for select to authenticated using (
  bucket_id = 'books' and (
    public.has_academy_role(array['admin','super_admin'])
    or split_part(name,'/',1) = any(public.my_unlocked_courses()) or '*' = any(public.my_unlocked_courses())
  )
);
-- Object path convention: books/<course-id>/<file>.pdf  e.g. books/mabda-1/book.pdf
-- Free-preview pages are served as a separate small PDF: books/preview/<course-id>.pdf (readable by any signed-in user):
drop policy if exists books_read_preview on storage.objects;
create policy books_read_preview on storage.objects for select to authenticated using (bucket_id = 'books' and split_part(name,'/',1) = 'preview');

-- 9) Paid lesson content lives in the database, NOT in the JS bundle: free rows are public, paid rows need an entitlement.
create table if not exists public.paid_content (
  course_id text not null,
  lesson_key text not null,
  kind text not null check (kind in ('vocab','text','lesson')),
  is_free boolean not null default false,
  data jsonb not null,
  primary key (course_id, lesson_key)
);
alter table public.paid_content enable row level security;
drop policy if exists paid_content_read on public.paid_content;
create policy paid_content_read on public.paid_content for select using (
  is_free
  or public.has_academy_role(array['admin','super_admin','teacher'])
  or (auth.uid() is not null and course_id = any(public.my_unlocked_courses()))
);
drop policy if exists paid_content_admin_write on public.paid_content;
create policy paid_content_admin_write on public.paid_content for all to authenticated
  using (public.has_academy_role(array['admin','super_admin'])) with check (public.has_academy_role(array['admin','super_admin']));
-- After this file, run seed-mabda3-content.sql to load the 57 vocabulary groups and 58 reading texts.
