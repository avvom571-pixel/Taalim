// Builds short free-preview PDFs from the full books (run: node scripts/make-previews.mjs).
// Needs: npm i -D pdf-lib   (full books live in private-books/, never in public/)
import fs from "node:fs";
import { PDFDocument } from "pdf-lib";
const PAGES = Number(process.env.PREVIEW_PAGES ?? 12);
for (const id of ["mabda-1", "mabda-2"]) {
  const src = await PDFDocument.load(fs.readFileSync(`private-books/${id}.pdf`));
  const out = await PDFDocument.create();
  const idx = Array.from({ length: Math.min(PAGES, src.getPageCount()) }, (_, i) => i);
  (await out.copyPages(src, idx)).forEach((p) => out.addPage(p));
  fs.writeFileSync(`public/previews/${id}-preview.pdf`, await out.save());
  console.log(id, "->", idx.length, "of", src.getPageCount(), "pages");
}
