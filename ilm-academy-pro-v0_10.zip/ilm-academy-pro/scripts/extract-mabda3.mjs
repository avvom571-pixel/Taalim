// Extracts VOCAB and TEXTS from the bundled Mabdaul Qiroat HTML into typed data files.
import fs from "node:fs";
const html = fs.readFileSync("private-books/mabda3-source.html", "utf8");
function grab(name) {
  const start = html.indexOf(`const ${name} = [`);
  if (start < 0) throw new Error(name + " not found");
  let i = html.indexOf("[", start), depth = 0, inStr = false, q = "", esc = false;
  for (let j = i; j < html.length; j++) {
    const c = html[j];
    if (inStr) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === q) inStr = false; continue; }
    if (c === '"' || c === "'" || c === "`") { inStr = true; q = c; continue; }
    if (c === "[") depth++;
    if (c === "]" && --depth === 0) return (0, eval)("(" + html.slice(i, j + 1) + ")");
  }
}
const vocab = grab("VOCAB"), texts = grab("TEXTS");
fs.mkdirSync("src/data", { recursive: true });
fs.writeFileSync("src/data/_vocab.tmp.json", JSON.stringify(vocab));
fs.writeFileSync("src/data/_texts.tmp.json", JSON.stringify(texts));
const groups = new Set(vocab.map(v => v.d));
console.log({ vocab: vocab.length, vocabGroups: groups.size, texts: texts.length, textPairs: texts.reduce((a, t) => a + t.pairs.length, 0), keys: Object.keys(texts[0]), pairKeys: Object.keys(texts[0].pairs[0]) });
