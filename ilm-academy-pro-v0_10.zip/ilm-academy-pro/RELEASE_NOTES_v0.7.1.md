# ILM ACADEMY PRO v0.7.1

- Иккала Мабдаъ ул-қироат PDF китоби платформага уланди.
- PDF reader responsive кўринишда қўшилди.
- Auth session network error handling қўшилди.
- Runtime ErrorBoundary қўшилди.
- Node dependencies ZIP'да атайлаб йўқ: `npm install` талаб қилинади.
- Бу версияда интерактив дарслар, серверда прогресс сақлаш ва админ контент CRUD тўлиқ эмас.
