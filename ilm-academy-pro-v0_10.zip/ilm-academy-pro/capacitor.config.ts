import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "com.ilmacademy.pro",
  appName: "ILM ACADEMY PRO",
  webDir: "dist",
  server: { androidScheme: "https" }
};
export default config;